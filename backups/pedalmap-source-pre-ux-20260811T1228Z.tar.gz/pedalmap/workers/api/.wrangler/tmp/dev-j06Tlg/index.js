var __defProp = Object.defineProperty;
var __name = (target, value) => __defProp(target, "name", { value, configurable: true });

// src/types.ts
var ORS_BASE = "https://api.heigit.org/openrouteservice";
function allowedOrigins(env) {
  return (env.ALLOWED_ORIGINS || "").split(",").map((s) => s.trim()).filter(Boolean);
}
__name(allowedOrigins, "allowedOrigins");
function isOriginAllowed(env, origin) {
  if (!origin) return false;
  const allowed = allowedOrigins(env);
  return allowed.includes("*") || allowed.includes(origin);
}
__name(isOriginAllowed, "isOriginAllowed");
function resolveAppUrl(env, request) {
  const origin = request.headers.get("Origin") || "";
  if (isOriginAllowed(env, origin)) return origin.replace(/\/+$/, "");
  return (env.APP_URL || "").replace(/\/+$/, "");
}
__name(resolveAppUrl, "resolveAppUrl");
function corsHeaders(env, request) {
  const origin = request.headers.get("Origin") || "";
  const allowed = allowedOrigins(env);
  const allowOrigin = origin && (allowed.includes(origin) || allowed.includes("*")) ? origin : allowed[0] || "*";
  return {
    "Access-Control-Allow-Origin": allowOrigin,
    "Access-Control-Allow-Methods": "GET,POST,OPTIONS",
    "Access-Control-Allow-Headers": "Content-Type, Authorization, Stripe-Signature",
    "Access-Control-Max-Age": "86400"
  };
}
__name(corsHeaders, "corsHeaders");
function json(data, status = 200, extra) {
  return new Response(JSON.stringify(data), {
    status,
    headers: {
      "Content-Type": "application/json",
      ...extra || {}
    }
  });
}
__name(json, "json");

// src/ors.ts
var PROFILE_RE = /^cycling-(regular|road|mountain|electric)$/;
async function handleOrsProxy(request, env, path) {
  if (!env.ORS_API_KEY) {
    return json({ error: "ORS_API_KEY not configured on worker" }, 500);
  }
  const match = path.match(/\/v2\/directions\/(cycling-(?:regular|road|mountain|electric))\/geojson\/?$/);
  const profile = match?.[1];
  if (!profile || !PROFILE_RE.test(profile)) {
    return json(
      {
        error: "Invalid cycling profile",
        hint: "POST /v2/directions/{cycling-*}/geojson"
      },
      400
    );
  }
  const body = await request.text();
  let upstream;
  try {
    upstream = await fetch(`${ORS_BASE}/v2/directions/${profile}/geojson`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Accept: "application/json, application/geo+json",
        Authorization: env.ORS_API_KEY
      },
      body
    });
  } catch (error) {
    const message2 = error instanceof Error ? error.message : "ORS upstream unreachable";
    return json(
      {
        error: "ORS network error",
        message: message2,
        profile,
        maintenance: false
      },
      502
    );
  }
  const text = await upstream.text();
  const contentType = upstream.headers.get("Content-Type") || "";
  const looksHtml = contentType.includes("text/html") || text.trimStart().startsWith("<!");
  const maintenance = upstream.status === 503 || text.toLowerCase().includes("down for maintenance");
  if (maintenance || looksHtml && upstream.status >= 500) {
    return json(
      {
        error: "OpenRouteService temporarily unavailable",
        maintenance: true,
        profile,
        status: upstream.status
      },
      503
    );
  }
  return new Response(text, {
    status: upstream.status,
    headers: {
      "Content-Type": contentType.includes("json") ? contentType : "application/json"
    }
  });
}
__name(handleOrsProxy, "handleOrsProxy");

// src/valhalla.ts
var DEFAULT_VALHALLA = "https://valhalla1.openstreetmap.de";
var USER_AGENT = "PedalMap/1.0 (+https://pedalmap-79b3a.web.app; bike routing)";
function resolveUpstream(env, action) {
  if (env.STADIA_API_KEY) {
    const path = action === "route" ? "/route/v1" : action === "trace_attributes" ? "/trace_attributes/v1" : "/elevation/v1";
    return {
      url: `https://api.stadiamaps.com${path}?api_key=${encodeURIComponent(env.STADIA_API_KEY)}`,
      headers: {
        "Content-Type": "application/json",
        Accept: "application/json"
      }
    };
  }
  const base = (env.VALHALLA_URL || DEFAULT_VALHALLA).replace(/\/+$/, "");
  return {
    url: `${base}/${action}`,
    headers: {
      "Content-Type": "application/json",
      Accept: "application/json",
      "User-Agent": USER_AGENT
    }
  };
}
__name(resolveUpstream, "resolveUpstream");
async function handleValhallaProxy(request, env, action) {
  const body = await request.text();
  const upstream = resolveUpstream(env, action);
  let response;
  try {
    response = await fetch(upstream.url, {
      method: "POST",
      headers: upstream.headers,
      body
    });
  } catch (error) {
    const message2 = error instanceof Error ? error.message : "Valhalla unreachable";
    return json({ error: "Valhalla network error", message: message2 }, 502);
  }
  const text = await response.text();
  return new Response(text, {
    status: response.status,
    headers: {
      "Content-Type": response.headers.get("Content-Type") || "application/json"
    }
  });
}
__name(handleValhallaProxy, "handleValhallaProxy");

// src/bikeRoute.ts
var DEFAULT_VALHALLA2 = "https://valhalla1.openstreetmap.de";
var USER_AGENT2 = "PedalMap/1.0 (+https://pedalmap-79b3a.web.app; bike routing)";
function resolveUpstream2(env, action) {
  if (env.STADIA_API_KEY) {
    const path = action === "route" ? "/route/v1" : action === "trace_attributes" ? "/trace_attributes/v1" : "/elevation/v1";
    return {
      url: `https://api.stadiamaps.com${path}?api_key=${encodeURIComponent(env.STADIA_API_KEY)}`,
      headers: { "Content-Type": "application/json", Accept: "application/json" }
    };
  }
  const base = (env.VALHALLA_URL || DEFAULT_VALHALLA2).replace(/\/+$/, "");
  return {
    url: `${base}/${action}`,
    headers: {
      "Content-Type": "application/json",
      Accept: "application/json",
      "User-Agent": USER_AGENT2
    }
  };
}
__name(resolveUpstream2, "resolveUpstream");
async function valhallaPost(env, action, body) {
  const upstream = resolveUpstream2(env, action);
  const res = await fetch(upstream.url, {
    method: "POST",
    headers: upstream.headers,
    body: JSON.stringify(body)
  });
  const text = await res.text();
  if (!res.ok) {
    throw new Error(`Valhalla ${action} ${res.status}: ${text.slice(0, 240)}`);
  }
  return JSON.parse(text);
}
__name(valhallaPost, "valhallaPost");
function bicycleCosting(bikeType, preferences = []) {
  const base = (() => {
    switch (bikeType) {
      case "road":
        return {
          bicycle_type: "Road",
          avoid_bad_surfaces: 1,
          use_roads: 0.55,
          use_hills: 0.12,
          use_ferry: 0.1,
          cycling_speed: 25
        };
      case "urban":
        return {
          bicycle_type: "Hybrid",
          avoid_bad_surfaces: 0.92,
          use_roads: 0.5,
          use_hills: 0.18,
          use_ferry: 0.15,
          cycling_speed: 18
        };
      case "ebike":
        return {
          bicycle_type: "Hybrid",
          avoid_bad_surfaces: 0.88,
          use_roads: 0.55,
          use_hills: 0.45,
          use_ferry: 0.2,
          cycling_speed: 22
        };
      case "gravel":
        return {
          bicycle_type: "Cross",
          avoid_bad_surfaces: 0.28,
          use_roads: 0.32,
          use_hills: 0.42,
          use_ferry: 0.15,
          cycling_speed: 20
        };
      case "mtb":
      default:
        return {
          bicycle_type: "Mountain",
          avoid_bad_surfaces: 0.05,
          use_roads: 0.18,
          use_hills: 0.62,
          use_ferry: 0.1,
          cycling_speed: 16
        };
    }
  })();
  if (preferences.includes("avoid_unpaved")) {
    base.avoid_bad_surfaces = Math.min(1, Math.max(Number(base.avoid_bad_surfaces), 0.95));
    base.use_roads = Math.max(Number(base.use_roads), 0.55);
  }
  if (preferences.includes("prefer_unpaved")) {
    base.bicycle_type = bikeType === "mtb" ? "Mountain" : "Cross";
    base.avoid_bad_surfaces = Math.min(Number(base.avoid_bad_surfaces), 0.2);
    base.use_roads = Math.min(Number(base.use_roads), 0.25);
  }
  if (preferences.includes("prefer_less_elevation")) {
    base.use_hills = Math.min(Number(base.use_hills), 0.1);
  }
  if (preferences.includes("prefer_bike_lanes") || preferences.includes("avoid_primary_roads")) {
    base.use_roads = Math.min(Number(base.use_roads), 0.35);
  }
  if (preferences.includes("prefer_secondary_roads")) {
    base.use_roads = Math.min(Math.max(Number(base.use_roads), 0.35), 0.5);
  }
  if (preferences.includes("avoid_traffic")) {
    base.use_roads = Math.min(Number(base.use_roads), 0.4);
    base.use_ferry = Math.min(Number(base.use_ferry), 0.05);
  }
  return base;
}
__name(bicycleCosting, "bicycleCosting");
function decodePolyline(encoded, precision = 6) {
  const coordinates = [];
  let index = 0;
  let lat = 0;
  let lng = 0;
  const factor = 10 ** precision;
  while (index < encoded.length) {
    let result = 0;
    let shift = 0;
    let byte = 0;
    do {
      byte = encoded.charCodeAt(index++) - 63;
      result |= (byte & 31) << shift;
      shift += 5;
    } while (byte >= 32);
    const dlat = result & 1 ? ~(result >> 1) : result >> 1;
    lat += dlat;
    result = 0;
    shift = 0;
    do {
      byte = encoded.charCodeAt(index++) - 63;
      result |= (byte & 31) << shift;
      shift += 5;
    } while (byte >= 32);
    const dlng = result & 1 ? ~(result >> 1) : result >> 1;
    lng += dlng;
    coordinates.push([lng / factor, lat / factor]);
  }
  return coordinates;
}
__name(decodePolyline, "decodePolyline");
function offsetLatLng(origin, bearingDeg, distanceMeters) {
  const R = 6371e3;
  const br = bearingDeg * Math.PI / 180;
  const lat1 = origin.lat * Math.PI / 180;
  const lng1 = origin.lng * Math.PI / 180;
  const ang = distanceMeters / R;
  const lat2 = Math.asin(
    Math.sin(lat1) * Math.cos(ang) + Math.cos(lat1) * Math.sin(ang) * Math.cos(br)
  );
  const lng2 = lng1 + Math.atan2(
    Math.sin(br) * Math.sin(ang) * Math.cos(lat1),
    Math.cos(ang) - Math.sin(lat1) * Math.sin(lat2)
  );
  return { lat: lat2 * 180 / Math.PI, lng: lng2 * 180 / Math.PI };
}
__name(offsetLatLng, "offsetLatLng");
function haversine(a, b) {
  const R = 6371e3;
  const toRad = /* @__PURE__ */ __name((d) => d * Math.PI / 180, "toRad");
  const dLat = toRad(b[1] - a[1]);
  const dLng = toRad(b[0] - a[0]);
  const lat1 = toRad(a[1]);
  const lat2 = toRad(b[1]);
  const h = Math.sin(dLat / 2) ** 2 + Math.cos(lat1) * Math.cos(lat2) * Math.sin(dLng / 2) ** 2;
  return 2 * R * Math.asin(Math.sqrt(h));
}
__name(haversine, "haversine");
function sampleEvenly(coords, maxPoints) {
  if (coords.length <= 2) return coords;
  const cum = [0];
  for (let i = 1; i < coords.length; i += 1) {
    cum.push(cum[i - 1] + haversine(coords[i - 1], coords[i]));
  }
  const total = cum[cum.length - 1];
  if (total <= 0) return [coords[0], coords[coords.length - 1]];
  const n = Math.max(2, Math.min(maxPoints, coords.length));
  const out = [];
  for (let i = 0; i < n; i += 1) {
    const target = i / (n - 1) * total;
    let j = 1;
    while (j < cum.length && cum[j] < target) j += 1;
    const i1 = Math.max(1, j);
    const i0 = i1 - 1;
    const seg = cum[i1] - cum[i0] || 1;
    const t = (target - cum[i0]) / seg;
    const a = coords[i0];
    const b = coords[i1];
    out.push([a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t]);
  }
  return out;
}
__name(sampleEvenly, "sampleEvenly");
function pointAtDistance(coords, targetMeters) {
  if (!coords.length) return { lng: 0, lat: 0 };
  if (coords.length === 1 || targetMeters <= 0) {
    return { lng: coords[0][0], lat: coords[0][1] };
  }
  let acc = 0;
  for (let i = 1; i < coords.length; i += 1) {
    const a = coords[i - 1];
    const b = coords[i];
    const seg = haversine(a, b);
    if (acc + seg >= targetMeters) {
      const t = seg > 0 ? (targetMeters - acc) / seg : 0;
      return { lng: a[0] + (b[0] - a[0]) * t, lat: a[1] + (b[1] - a[1]) * t };
    }
    acc += seg;
  }
  const last = coords[coords.length - 1];
  return { lng: last[0], lat: last[1] };
}
__name(pointAtDistance, "pointAtDistance");
function mergeLegShapes(legs) {
  const all = [];
  for (const leg of legs) {
    if (!leg.shape) continue;
    const part = decodePolyline(leg.shape);
    if (!part.length) continue;
    if (!all.length) {
      all.push(...part);
      continue;
    }
    all.push(...part.slice(1));
  }
  return all;
}
__name(mergeLegShapes, "mergeLegShapes");
var ROUTE_ELEVATION_INTERVAL_M = 30;
function profileFromRouteLegs(legs, coordinates) {
  const out = [];
  let offsetM = 0;
  for (const leg of legs) {
    const elevs = leg.elevation;
    if (!elevs?.length) {
      offsetM += Math.round((leg.summary?.length ?? 0) * 1e3);
      continue;
    }
    const interval = Math.max(1, leg.elevation_interval ?? ROUTE_ELEVATION_INTERVAL_M);
    for (let i = 0; i < elevs.length; i += 1) {
      const elev = elevs[i];
      if (elev === null || elev === void 0 || !Number.isFinite(elev)) continue;
      const distanceMeters = offsetM + i * interval;
      out.push({
        distanceMeters,
        elevationMeters: elev,
        position: pointAtDistance(coordinates, distanceMeters)
      });
    }
    offsetM += (elevs.length - 1) * interval;
  }
  return out;
}
__name(profileFromRouteLegs, "profileFromRouteLegs");
function profileFromHeightResponse(height, sampled) {
  const heightBody = height;
  if (heightBody.range_height?.length) {
    return heightBody.range_height.map(([rangeM, elev], i) => {
      if (elev === null || elev === void 0 || !Number.isFinite(elev)) return null;
      const c = sampled[Math.min(i, sampled.length - 1)];
      return {
        distanceMeters: rangeM,
        elevationMeters: elev,
        position: { lng: c[0], lat: c[1] }
      };
    }).filter((p) => Boolean(p));
  }
  if (heightBody.height?.length) {
    let acc = 0;
    return heightBody.height.map((elev, i) => {
      const c = sampled[Math.min(i, sampled.length - 1)];
      if (i > 0) acc += haversine(sampled[i - 1], c);
      if (elev === null || elev === void 0 || !Number.isFinite(elev)) return null;
      return {
        distanceMeters: acc,
        elevationMeters: elev,
        position: { lng: c[0], lat: c[1] }
      };
    }).filter((p) => Boolean(p));
  }
  return [];
}
__name(profileFromHeightResponse, "profileFromHeightResponse");
async function enrichTrip(env, trip, costing) {
  const legs = trip.legs ?? [];
  const coordinates = mergeLegShapes(legs);
  if (coordinates.length < 2) throw new Error("Invalid Valhalla geometry");
  const distanceMeters = Math.round((trip.summary?.length ?? 0) * 1e3);
  const durationSeconds = Math.round(trip.summary?.time ?? 0);
  const instructions = legs.flatMap((l) => l.maneuvers?.map((m) => m.instruction ?? "").filter(Boolean) ?? []) ?? [];
  let elevationProfile = profileFromRouteLegs(legs, coordinates);
  const sampleBudget = coordinates.length > 1200 ? 72 : 96;
  const sampled = sampleEvenly(coordinates, sampleBudget);
  const needHeightFallback = elevationProfile.length < 8;
  const [attrs, height] = await Promise.all([
    valhallaPost(env, "trace_attributes", {
      shape: sampled.map(([lng, lat]) => ({ lat, lon: lng })),
      shape_match: "map_snap",
      costing: "bicycle",
      costing_options: { bicycle: costing },
      filters: {
        action: "include",
        attributes: [
          "edge.length",
          "edge.surface",
          "edge.road_class",
          "edge.use",
          "edge.cycle_lane"
        ]
      }
    }).catch(() => ({ edges: [] })),
    needHeightFallback ? valhallaPost(env, "height", {
      range: true,
      shape: sampled.map(([lng, lat]) => ({ lat, lon: lng }))
    }).catch(() => ({ range_height: [] })) : Promise.resolve(null)
  ]);
  if (needHeightFallback && height) {
    elevationProfile = profileFromHeightResponse(height, sampled);
  }
  return {
    coordinates,
    elevationProfile,
    edges: attrs.edges ?? [],
    distanceMeters,
    durationSeconds,
    instructions
  };
}
__name(enrichTrip, "enrichTrip");
async function routeLocations(env, locations, costing, language, options) {
  const elevationInterval = options?.elevationIntervalM ?? // Longer shapes (typical ida-vuelta) use a slightly coarser DEM interval for speed.
  (locations.length >= 3 ? 40 : ROUTE_ELEVATION_INTERVAL_M);
  const routeJson = await valhallaPost(env, "route", {
    locations,
    costing: "bicycle",
    costing_options: { bicycle: costing },
    directions_options: {
      units: "kilometers",
      language: language === "en" ? "en-US" : "es-ES"
    },
    elevation_interval: elevationInterval,
    ...options?.alternates && options.alternates > 0 ? { alternates: Math.min(3, Math.floor(options.alternates)) } : {}
  });
  if (routeJson.error || !routeJson.trip?.legs?.length) {
    throw new Error(routeJson.error || "No route found");
  }
  const primary = await enrichTrip(env, routeJson.trip, costing);
  const alternateTrips = Array.isArray(routeJson.alternates) ? routeJson.alternates : [];
  const alternatives = (await Promise.all(
    alternateTrips.map(
      (trip) => trip?.legs?.length ? enrichTrip(env, trip, costing).catch((err) => {
        console.warn("[bike-route] alternate enrich failed", err);
        return null;
      }) : Promise.resolve(null)
    )
  )).filter((x) => Boolean(x));
  return { ...primary, alternatives };
}
__name(routeLocations, "routeLocations");
function routeFingerprint(route) {
  const coords = route.coordinates;
  const mid = coords[Math.floor(coords.length / 2)] ?? coords[0];
  const end = coords[coords.length - 1] ?? coords[0];
  return [
    Math.round(route.distanceMeters / 80),
    mid[0].toFixed(3),
    mid[1].toFixed(3),
    end[0].toFixed(3),
    end[1].toFixed(3)
  ].join("|");
}
__name(routeFingerprint, "routeFingerprint");
function costingVariant(base, tweak) {
  const next = { ...base };
  const num = /* @__PURE__ */ __name((key, fallback) => typeof next[key] === "number" ? next[key] : fallback, "num");
  if (tweak === "roads") {
    next.use_roads = Math.min(1, num("use_roads", 0.5) + 0.28);
    next.use_hills = Math.max(0, num("use_hills", 0.2) - 0.08);
    next.avoid_bad_surfaces = Math.min(1, num("avoid_bad_surfaces", 0.5) + 0.15);
  } else if (tweak === "hills") {
    next.use_hills = Math.min(1, num("use_hills", 0.2) + 0.35);
    next.use_roads = Math.max(0.1, num("use_roads", 0.5) - 0.12);
  } else {
    next.use_roads = Math.max(0.15, num("use_roads", 0.5) - 0.22);
    next.avoid_bad_surfaces = Math.max(0, num("avoid_bad_surfaces", 0.5) - 0.25);
    next.use_hills = Math.min(1, num("use_hills", 0.2) + 0.12);
  }
  return next;
}
__name(costingVariant, "costingVariant");
function mergeUniqueRoutes(routes, max = 3) {
  const out = [];
  const seen = /* @__PURE__ */ new Set();
  for (const route of routes) {
    if (!route?.coordinates || route.coordinates.length < 2) continue;
    const key = routeFingerprint(route);
    if (seen.has(key)) continue;
    seen.add(key);
    out.push(route);
    if (out.length >= max) break;
  }
  return out;
}
__name(mergeUniqueRoutes, "mergeUniqueRoutes");
async function routeLocationsWithOptions(env, locations, costing, language, mode = "a_to_b") {
  if (mode === "out_and_back") {
    const main2 = await routeLocations(env, locations, costing, language, { alternates: 2 });
    const unique2 = mergeUniqueRoutes([main2, ...main2.alternatives ?? []], 3);
    const primary2 = unique2[0] ?? main2;
    return { ...primary2, alternatives: unique2.slice(1) };
  }
  if (!env.STADIA_API_KEY) {
    const main2 = await routeLocations(env, locations, costing, language, { alternates: 2 });
    const unique2 = mergeUniqueRoutes([main2, ...main2.alternatives ?? []], 3);
    const primary2 = unique2[0] ?? main2;
    return { ...primary2, alternatives: unique2.slice(1) };
  }
  const [mainSettled, roadsSettled, hillsSettled] = await Promise.allSettled([
    routeLocations(env, locations, costing, language, { alternates: 2 }),
    routeLocations(env, locations, costingVariant(costing, "roads"), language),
    routeLocations(env, locations, costingVariant(costing, "mixed"), language)
  ]);
  if (mainSettled.status !== "fulfilled") {
    const fallback = [roadsSettled, hillsSettled].find((r) => r.status === "fulfilled");
    if (!fallback || fallback.status !== "fulfilled") throw mainSettled.reason;
    return { ...fallback.value, alternatives: [] };
  }
  const main = mainSettled.value;
  const extras = [...main.alternatives ?? []];
  if (roadsSettled.status === "fulfilled") extras.push(roadsSettled.value);
  if (hillsSettled.status === "fulfilled") extras.push(hillsSettled.value);
  const unique = mergeUniqueRoutes([main, ...extras], 3);
  const primary = unique[0] ?? main;
  const alternatives = unique.slice(1);
  return { ...primary, alternatives };
}
__name(routeLocationsWithOptions, "routeLocationsWithOptions");
async function handleBikeRoute(request, env) {
  let body;
  try {
    body = await request.json();
  } catch {
    return json({ error: "Invalid JSON body" }, 400);
  }
  const {
    bikeType = "road",
    preferences = [],
    routeType = "a_to_b",
    waypoints = [],
    circularDistanceMeters,
    targetElevationGainMeters,
    language = "es",
    circularSeed = 0,
    wantAlternatives = false
  } = body;
  if (!Array.isArray(waypoints) || waypoints.length < 1) {
    return json({ error: "waypoints required" }, 400);
  }
  const costing = bicycleCosting(bikeType, preferences);
  try {
    if (routeType === "circular") {
      if (!circularDistanceMeters || circularDistanceMeters < 1e3) {
        return json({ error: "circularDistanceMeters required (>=1000)" }, 400);
      }
      const start = waypoints[0];
      const wantElev = Boolean(targetElevationGainMeters && targetElevationGainMeters > 0);
      const seed = circularSeed || 0;
      const attempts = [
        { bearing: seed * 47 % 360, legFactor: 5, costing },
        { bearing: (seed * 47 + 90) % 360, legFactor: 4.2, costing },
        { bearing: (seed * 47 + 180) % 360, legFactor: 4.6, costing },
        { bearing: (seed * 47 + 270) % 360, legFactor: 3.8, costing }
      ];
      if (wantElev) {
        const hills = costingVariant(costing, "hills");
        attempts.push(
          { bearing: (seed * 47 + 35) % 360, legFactor: 4.5, costing: hills },
          { bearing: (seed * 47 + 215) % 360, legFactor: 4, costing: hills }
        );
      }
      const settled = await Promise.all(
        (env.STADIA_API_KEY ? attempts : attempts.slice(0, 4)).map(
          async ({ bearing, legFactor, costing: attemptCosting }, i) => {
            const leg = circularDistanceMeters / legFactor;
            const via1 = offsetLatLng(start, bearing, leg);
            const via2 = offsetLatLng(start, bearing + 120, leg);
            try {
              const candidate = await routeLocations(
                env,
                [
                  { lat: start.lat, lon: start.lng, type: "break" },
                  { lat: via1.lat, lon: via1.lng, type: "break" },
                  { lat: via2.lat, lon: via2.lng, type: "break" },
                  { lat: start.lat, lon: start.lng, type: "break" }
                ],
                attemptCosting,
                language
              );
              const distErr = Math.abs(candidate.distanceMeters - circularDistanceMeters) / Math.max(1, circularDistanceMeters);
              let elevErr = 0;
              if (wantElev && targetElevationGainMeters) {
                let gain = 0;
                for (let p = 1; p < candidate.elevationProfile.length; p += 1) {
                  const d = candidate.elevationProfile[p].elevationMeters - candidate.elevationProfile[p - 1].elevationMeters;
                  if (d > 2.5) gain += d;
                }
                elevErr = Math.abs(gain - targetElevationGainMeters) / Math.max(40, targetElevationGainMeters);
              }
              const score = distErr * 100 + elevErr * (wantElev ? 55 : 0);
              return { candidate, score, i };
            } catch (err) {
              console.warn("[bike-route] circular attempt failed", i, err);
              return null;
            }
          }
        )
      );
      const ranked = settled.filter((row) => Boolean(row)).sort((a, b) => a.score - b.score);
      if (!ranked.length) return json({ error: "No circular route found" }, 404);
      const best = ranked[0].candidate;
      const { alternatives: _alts, ...primary } = best;
      const alternatives = ranked.slice(1, 3).map((row, idx) => {
        const { alternatives: _a, ...rest } = row.candidate;
        return { ...rest, label: `Variante ${idx + 2}` };
      });
      return json({
        ok: true,
        provider: "valhalla",
        bikeType,
        routeType,
        ...primary,
        alternatives
      });
    }
    if (waypoints.length < 2) {
      return json({ error: "At least two waypoints required" }, 400);
    }
    const pts = routeType === "out_and_back" ? [...waypoints, waypoints[0]] : waypoints;
    const locations = pts.map((w) => ({ lat: w.lat, lon: w.lng, type: "break" }));
    const wantsOptions = wantAlternatives && (routeType === "a_to_b" || routeType === "out_and_back");
    const result = wantsOptions ? await routeLocationsWithOptions(
      env,
      locations,
      costing,
      language,
      routeType === "out_and_back" ? "out_and_back" : "a_to_b"
    ) : await routeLocations(env, locations, costing, language, {
      elevationIntervalM: routeType === "out_and_back" ? 40 : ROUTE_ELEVATION_INTERVAL_M
    });
    return json({ ok: true, provider: "valhalla", bikeType, routeType, ...result });
  } catch (error) {
    const message2 = error instanceof Error ? error.message : "Valhalla bike-route failed";
    console.error("[bike-route]", message2);
    return json({ error: message2 }, 502);
  }
}
__name(handleBikeRoute, "handleBikeRoute");

// node_modules/jose/dist/webapi/lib/buffer_utils.js
var encoder = new TextEncoder();
var decoder = new TextDecoder();
var strictDecoder = new TextDecoder("utf-8", { fatal: true });
var MAX_INT32 = 2 ** 32;
function concat(...buffers) {
  const size = buffers.reduce((acc, { length }) => acc + length, 0);
  const buf = new Uint8Array(size);
  let i = 0;
  for (const buffer of buffers) {
    buf.set(buffer, i);
    i += buffer.length;
  }
  return buf;
}
__name(concat, "concat");
function encode(string) {
  const bytes = new Uint8Array(string.length);
  for (let i = 0; i < string.length; i++) {
    const code = string.charCodeAt(i);
    if (code > 127) {
      throw new TypeError("non-ASCII string encountered in encode()");
    }
    bytes[i] = code;
  }
  return bytes;
}
__name(encode, "encode");

// node_modules/jose/dist/webapi/lib/crypto_key.js
var unusable = /* @__PURE__ */ __name((name, prop = "algorithm.name") => new TypeError(`CryptoKey does not support this operation, its ${prop} must be ${name}`), "unusable");
function checkUsage(key, usage) {
  if (usage && !key.usages.includes(usage)) {
    throw new TypeError(`CryptoKey does not support this operation, its usages must include ${usage}.`);
  }
}
__name(checkUsage, "checkUsage");
function checkModulusLength(alg, key) {
  const { modulusLength } = key.algorithm;
  if (typeof modulusLength !== "number" || modulusLength < 2048) {
    throw new TypeError(`${alg} requires key modulusLength to be 2048 bits or larger`);
  }
}
__name(checkModulusLength, "checkModulusLength");
function checkCryptoKey(key, expected, usage) {
  const algorithm = key.algorithm;
  if (algorithm.name !== expected.name) {
    throw unusable(expected.name);
  }
  if (expected.hash && algorithm.hash?.name !== expected.hash) {
    throw unusable(expected.hash, "algorithm.hash");
  }
  if (expected.namedCurve && algorithm.namedCurve !== expected.namedCurve) {
    throw unusable(expected.namedCurve, "algorithm.namedCurve");
  }
  if (expected.length !== void 0 && algorithm.length !== expected.length) {
    throw unusable(expected.length, "algorithm.length");
  }
  checkUsage(key, usage);
}
__name(checkCryptoKey, "checkCryptoKey");

// node_modules/jose/dist/webapi/lib/invalid_key_input.js
function message(msg, actual, ...types) {
  if (types.length > 2) {
    const last = types.pop();
    msg += `one of type ${types.join(", ")}, or ${last}.`;
  } else if (types.length === 2) {
    msg += `one of type ${types[0]} or ${types[1]}.`;
  } else {
    msg += `of type ${types[0]}.`;
  }
  if (actual == null) {
    msg += ` Received ${actual}`;
  } else if (typeof actual === "function" && actual.name) {
    msg += ` Received function ${actual.name}`;
  } else if (typeof actual === "object" && actual != null) {
    if (actual.constructor?.name) {
      msg += ` Received an instance of ${actual.constructor.name}`;
    }
  }
  return msg;
}
__name(message, "message");
var withAlg = /* @__PURE__ */ __name((alg, actual, ...types) => message(`Key for the ${alg} algorithm must be `, actual, ...types), "withAlg");

// node_modules/jose/dist/webapi/util/errors.js
var JOSEError = class extends Error {
  static {
    __name(this, "JOSEError");
  }
  static code = "ERR_JOSE_GENERIC";
  code = "ERR_JOSE_GENERIC";
  constructor(message2, options) {
    super(message2, options);
    this.name = this.constructor.name;
    Error.captureStackTrace?.(this, this.constructor);
  }
};
var JWTClaimValidationFailed = class extends JOSEError {
  static {
    __name(this, "JWTClaimValidationFailed");
  }
  static code = "ERR_JWT_CLAIM_VALIDATION_FAILED";
  code = "ERR_JWT_CLAIM_VALIDATION_FAILED";
  claim;
  reason;
  payload;
  constructor(message2, payload, claim = "unspecified", reason = "unspecified") {
    super(message2, { cause: { claim, reason, payload } });
    this.claim = claim;
    this.reason = reason;
    this.payload = payload;
  }
};
var JWTExpired = class extends JOSEError {
  static {
    __name(this, "JWTExpired");
  }
  static code = "ERR_JWT_EXPIRED";
  code = "ERR_JWT_EXPIRED";
  claim;
  reason;
  payload;
  constructor(message2, payload, claim = "unspecified", reason = "unspecified") {
    super(message2, { cause: { claim, reason, payload } });
    this.claim = claim;
    this.reason = reason;
    this.payload = payload;
  }
};
var JOSEAlgNotAllowed = class extends JOSEError {
  static {
    __name(this, "JOSEAlgNotAllowed");
  }
  static code = "ERR_JOSE_ALG_NOT_ALLOWED";
  code = "ERR_JOSE_ALG_NOT_ALLOWED";
};
var JOSENotSupported = class extends JOSEError {
  static {
    __name(this, "JOSENotSupported");
  }
  static code = "ERR_JOSE_NOT_SUPPORTED";
  code = "ERR_JOSE_NOT_SUPPORTED";
};
var JWSInvalid = class extends JOSEError {
  static {
    __name(this, "JWSInvalid");
  }
  static code = "ERR_JWS_INVALID";
  code = "ERR_JWS_INVALID";
};
var JWTInvalid = class extends JOSEError {
  static {
    __name(this, "JWTInvalid");
  }
  static code = "ERR_JWT_INVALID";
  code = "ERR_JWT_INVALID";
};
var JWKSInvalid = class extends JOSEError {
  static {
    __name(this, "JWKSInvalid");
  }
  static code = "ERR_JWKS_INVALID";
  code = "ERR_JWKS_INVALID";
};
var JWKSNoMatchingKey = class extends JOSEError {
  static {
    __name(this, "JWKSNoMatchingKey");
  }
  static code = "ERR_JWKS_NO_MATCHING_KEY";
  code = "ERR_JWKS_NO_MATCHING_KEY";
  constructor(message2 = "no applicable key found in the JSON Web Key Set", options) {
    super(message2, options);
  }
};
var JWKSMultipleMatchingKeys = class extends JOSEError {
  static {
    __name(this, "JWKSMultipleMatchingKeys");
  }
  [Symbol.asyncIterator] = async function* () {
  };
  static code = "ERR_JWKS_MULTIPLE_MATCHING_KEYS";
  code = "ERR_JWKS_MULTIPLE_MATCHING_KEYS";
  constructor(message2 = "multiple matching keys found in the JSON Web Key Set", options) {
    super(message2, options);
  }
};
var JWKSTimeout = class extends JOSEError {
  static {
    __name(this, "JWKSTimeout");
  }
  static code = "ERR_JWKS_TIMEOUT";
  code = "ERR_JWKS_TIMEOUT";
  constructor(message2 = "request timed out", options) {
    super(message2, options);
  }
};
var JWSSignatureVerificationFailed = class extends JOSEError {
  static {
    __name(this, "JWSSignatureVerificationFailed");
  }
  static code = "ERR_JWS_SIGNATURE_VERIFICATION_FAILED";
  code = "ERR_JWS_SIGNATURE_VERIFICATION_FAILED";
  constructor(message2 = "signature verification failed", options) {
    super(message2, options);
  }
};

// node_modules/jose/dist/webapi/lib/is_key_like.js
var isCryptoKey = /* @__PURE__ */ __name((key) => {
  if (key?.[Symbol.toStringTag] === "CryptoKey")
    return true;
  try {
    return key instanceof CryptoKey;
  } catch {
    return false;
  }
}, "isCryptoKey");
var isKeyObject = /* @__PURE__ */ __name((key) => key?.[Symbol.toStringTag] === "KeyObject", "isKeyObject");
var isKeyLike = /* @__PURE__ */ __name((key) => isCryptoKey(key) || isKeyObject(key), "isKeyLike");

// node_modules/jose/dist/webapi/lib/base64.js
function decodeBase64(encoded) {
  if (Uint8Array.fromBase64) {
    return Uint8Array.fromBase64(encoded);
  }
  const binary = atob(encoded);
  const bytes = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i++) {
    bytes[i] = binary.charCodeAt(i);
  }
  return bytes;
}
__name(decodeBase64, "decodeBase64");

// node_modules/jose/dist/webapi/util/base64url.js
var invalid = "The input to be decoded is not correctly encoded.";
function decode(input) {
  if (Uint8Array.fromBase64) {
    try {
      return Uint8Array.fromBase64(typeof input === "string" ? input : decoder.decode(input), {
        alphabet: "base64url"
      });
    } catch (cause) {
      throw new TypeError(invalid, { cause });
    }
  }
  let encoded = input;
  if (encoded instanceof Uint8Array) {
    encoded = decoder.decode(encoded);
  }
  if (encoded.includes("+") || encoded.includes("/")) {
    throw new TypeError(invalid);
  }
  encoded = encoded.replace(/-/g, "+").replace(/_/g, "/");
  try {
    return decodeBase64(encoded);
  } catch {
    throw new TypeError(invalid);
  }
}
__name(decode, "decode");

// node_modules/jose/dist/webapi/lib/type_checks.js
function isObject(input) {
  if (typeof input !== "object" || input === null || Object.prototype.toString.call(input) !== "[object Object]") {
    return false;
  }
  const prototype = Object.getPrototypeOf(input);
  if (prototype === null) {
    return true;
  }
  let proto = prototype;
  while (Object.getPrototypeOf(proto) !== null) {
    proto = Object.getPrototypeOf(proto);
  }
  return prototype === proto;
}
__name(isObject, "isObject");
function isDisjoint(...headers) {
  const parameters = /* @__PURE__ */ new Set();
  for (const header of headers) {
    if (!header)
      continue;
    for (const parameter of Object.keys(header)) {
      if (parameters.has(parameter)) {
        return false;
      }
      parameters.add(parameter);
    }
  }
  return true;
}
__name(isDisjoint, "isDisjoint");
var isJWK = /* @__PURE__ */ __name((key) => isObject(key) && typeof key.kty === "string", "isJWK");
var isPrivateJWK = /* @__PURE__ */ __name((key) => key.kty !== "oct" && (key.kty === "AKP" && typeof key.priv === "string" || typeof key.d === "string"), "isPrivateJWK");
var isPublicJWK = /* @__PURE__ */ __name((key) => key.kty !== "oct" && key.d === void 0 && key.priv === void 0, "isPublicJWK");
var isSecretJWK = /* @__PURE__ */ __name((key) => key.kty === "oct" && typeof key.k === "string", "isSecretJWK");

// node_modules/jose/dist/webapi/lib/helpers.js
function decodeBase64url(value, label, ErrorClass) {
  try {
    return decode(value);
  } catch {
    throw new ErrorClass(`Failed to base64url decode the ${label}`);
  }
}
__name(decodeBase64url, "decodeBase64url");
function encodeBase64url(value, label, ErrorClass) {
  try {
    return encode(value);
  } catch {
    throw new ErrorClass(`The ${label} is not a valid base64url string`);
  }
}
__name(encodeBase64url, "encodeBase64url");
function parseJoseHeader(b64, ErrorClass, message2) {
  let parsed;
  try {
    parsed = JSON.parse(strictDecoder.decode(decode(b64)));
  } catch {
    throw new ErrorClass(message2);
  }
  if (!isObject(parsed)) {
    throw new ErrorClass(message2);
  }
  return parsed;
}
__name(parseJoseHeader, "parseJoseHeader");

// node_modules/jose/dist/webapi/lib/jwk_to_key.js
async function jwkToKey(entry, jwk) {
  if (jwk.kty === "RSA" && "oth" in jwk && jwk.oth !== void 0) {
    throw new JOSENotSupported('RSA JWK "oth" (Other Primes Info) Parameter value is not supported');
  }
  if (!entry.kty.includes(jwk.kty)) {
    throw new JOSENotSupported('Invalid or unsupported JWK "alg" (Algorithm) Parameter value');
  }
  const algorithm = entry.resolve?.({ kty: jwk.kty, crv: jwk.crv }) ?? entry.subtle;
  const isPrivate = !!(jwk.d || jwk.priv);
  const keyData = { ...jwk };
  if (keyData.kty !== "AKP") {
    delete keyData.alg;
  }
  delete keyData.use;
  return crypto.subtle.importKey("jwk", keyData, algorithm, jwk.ext ?? !isPrivate, jwk.key_ops ?? entry.usages[isPrivate ? 1 : 0]);
}
__name(jwkToKey, "jwkToKey");

// node_modules/jose/dist/webapi/lib/key.js
var tag = /* @__PURE__ */ __name((key) => key[Symbol.toStringTag], "tag");
var jwkMatchesOp = /* @__PURE__ */ __name((entry, key, usage) => {
  const { alg } = entry;
  if (key.use !== void 0) {
    const expected = usage === "sign" || usage === "verify" ? "sig" : "enc";
    if (key.use !== expected) {
      throw new TypeError(`Invalid key for this operation, its "use" must be "${expected}" when present`);
    }
  }
  if (key.alg !== void 0 && key.alg !== alg) {
    throw new TypeError(`Invalid key for this operation, its "alg" must be "${alg}" when present`);
  }
  if (Array.isArray(key.key_ops)) {
    const expectedKeyOp = usage === "encrypt" || usage === "decrypt" ? entry.ops?.[usage === "encrypt" ? 0 : 1] : usage;
    if (expectedKeyOp && !key.key_ops.includes(expectedKeyOp)) {
      throw new TypeError(`Invalid key for this operation, its "key_ops" must include "${expectedKeyOp}" when present`);
    }
  }
}, "jwkMatchesOp");
function checkKeyType(entry, key, usage) {
  const { alg, secret } = entry;
  const privateKey = usage === "decrypt" || usage === "sign";
  if (secret && key instanceof Uint8Array)
    return [BYTES, key];
  if (isJWK(key)) {
    if (secret ? !isSecretJWK(key) : !(privateKey ? isPrivateJWK(key) : isPublicJWK(key))) {
      throw new TypeError(secret ? `JSON Web Key for symmetric algorithms must have JWK "kty" (Key Type) equal to "oct" and the JWK "k" (Key Value) present` : `JSON Web Key for this operation must be a ${privateKey ? "private" : "public"} JWK`);
    }
    jwkMatchesOp(entry, key, usage);
    return [JWK, key];
  }
  if (!isKeyLike(key)) {
    throw new TypeError(secret ? withAlg(alg, key, "CryptoKey", "KeyObject", "JSON Web Key", "Uint8Array") : withAlg(alg, key, "CryptoKey", "KeyObject", "JSON Web Key"));
  }
  if (secret) {
    if (key.type !== "secret") {
      throw new TypeError(`${tag(key)} instances for symmetric algorithms must be of type "secret"`);
    }
  } else {
    if (key.type === "secret") {
      throw new TypeError(`${tag(key)} instances for asymmetric algorithms must not be of type "secret"`);
    }
    const expectedType = privateKey ? "private" : "public";
    if ((key.type === "public" || key.type === "private") && key.type !== expectedType) {
      const operation = usage === "sign" ? "signing" : usage === "verify" ? "verifying" : `${usage.slice(0, -1)}tion`;
      throw new TypeError(`${tag(key)} instances for asymmetric algorithm ${operation} must be of type "${expectedType}"`);
    }
  }
  return isCryptoKey(key) ? [CRYPTO, key] : [KEYOBJECT, key];
}
__name(checkKeyType, "checkKeyType");
var BYTES = 0;
var CRYPTO = 1;
var KEYOBJECT = 2;
var JWK = 3;
var cache;
var nist = {
  __proto__: null,
  prime256v1: "P-256",
  secp384r1: "P-384",
  secp521r1: "P-521"
};
function cached(key, alg, value) {
  cache ||= /* @__PURE__ */ new WeakMap();
  const entry = cache.get(key);
  if (value) {
    if (entry) {
      entry[alg] = value;
    } else {
      cache.set(key, { __proto__: null, [alg]: value });
    }
  }
  return value ?? entry?.[alg];
}
__name(cached, "cached");
var handleJWK = /* @__PURE__ */ __name(async (key, jwk, entry) => cached(key, entry.alg) ?? cached(key, entry.alg, await jwkToKey(entry, { ...jwk, alg: entry.alg })), "handleJWK");
var handleKeyObject = /* @__PURE__ */ __name((keyObject, entry) => {
  const hit = cached(keyObject, entry.alg);
  if (hit)
    return hit;
  const isPublic = keyObject.type === "public";
  const usages = entry.usages[isPublic ? 0 : 1];
  const { asymmetricKeyType } = keyObject;
  const crv = nist[keyObject.asymmetricKeyDetails?.namedCurve];
  const params = entry.resolve?.({ crv, asymmetricKeyType }) ?? entry.subtle;
  return cached(keyObject, entry.alg, keyObject.toCryptoKey(params, isPublic, usages));
}, "handleKeyObject");
async function prepareKey(entry, key, usage) {
  const tagged = checkKeyType(entry, key, usage);
  switch (tagged[0]) {
    case BYTES:
    case CRYPTO:
      return tagged[1];
    case JWK: {
      const key2 = tagged[1];
      if (key2.k) {
        return decode(key2.k);
      }
      if (!Object.isFrozen(key2)) {
        const { key_ops } = key2;
        if (Array.isArray(key_ops))
          Object.freeze(key_ops);
        Object.freeze(key2);
      }
      return handleJWK(key2, key2, entry);
    }
    case KEYOBJECT: {
      const keyObject = tagged[1];
      if (keyObject.type === "secret") {
        return keyObject.export();
      }
      if ("toCryptoKey" in keyObject && typeof keyObject.toCryptoKey === "function") {
        return handleKeyObject(keyObject, entry);
      }
      return handleJWK(keyObject, keyObject.export({ format: "jwk" }), entry);
    }
  }
}
__name(prepareKey, "prepareKey");

// node_modules/jose/dist/webapi/lib/key_descriptor.js
function table(entries) {
  const out = { __proto__: null };
  for (const alg in entries) {
    out[alg] = { ...entries[alg], alg };
  }
  return out;
}
__name(table, "table");

// node_modules/jose/dist/webapi/lib/options.js
var JWS_RECOGNIZED = { __proto__: null, b64: true };
function validateAlgorithms(option, algorithms) {
  if (algorithms !== void 0 && (!Array.isArray(algorithms) || algorithms.some((s) => typeof s !== "string"))) {
    throw new TypeError(`"${option}" option must be an array of strings`);
  }
  if (!algorithms) {
    return void 0;
  }
  return new Set(algorithms);
}
__name(validateAlgorithms, "validateAlgorithms");
function validateCrit(Err, recognizedDefault, recognizedOption, protectedHeader, joseHeader) {
  if (joseHeader.crit !== void 0 && protectedHeader?.crit === void 0) {
    throw new Err('"crit" (Critical) Header Parameter MUST be integrity protected');
  }
  if (!protectedHeader || protectedHeader.crit === void 0) {
    return [];
  }
  if (!Array.isArray(protectedHeader.crit) || protectedHeader.crit.length === 0 || protectedHeader.crit.some((input) => typeof input !== "string" || input.length === 0)) {
    throw new Err('"crit" (Critical) Header Parameter MUST be an array of non-empty strings when present');
  }
  const recognized = recognizedOption === void 0 ? recognizedDefault : { __proto__: null, ...recognizedOption, ...recognizedDefault };
  for (const parameter of protectedHeader.crit) {
    if (!(parameter in recognized)) {
      throw new JOSENotSupported(`Extension Header Parameter "${parameter}" is not recognized`);
    }
    if (!Object.hasOwn(joseHeader, parameter) || joseHeader[parameter] === void 0) {
      throw new Err(`Extension Header Parameter "${parameter}" is missing`);
    }
    if (recognized[parameter] && (!Object.hasOwn(protectedHeader, parameter) || protectedHeader[parameter] === void 0)) {
      throw new Err(`Extension Header Parameter "${parameter}" MUST be integrity protected`);
    }
  }
  return protectedHeader.crit;
}
__name(validateCrit, "validateCrit");

// node_modules/jose/dist/webapi/lib/signing.js
async function getSigKey(entry, key, usage) {
  if (key instanceof Uint8Array) {
    return crypto.subtle.importKey("raw", key, entry.subtle, false, [
      usage
    ]);
  }
  checkCryptoKey(key, entry.subtle, usage);
  if (entry.minRsaBits)
    checkModulusLength(entry.alg, key);
  return key;
}
__name(getSigKey, "getSigKey");
async function verify(entry, key, signature, data) {
  const cryptoKey = await getSigKey(entry, key, "verify");
  try {
    return await crypto.subtle.verify(entry.signing, cryptoKey, signature, data);
  } catch {
    return false;
  }
}
__name(verify, "verify");

// node_modules/jose/dist/webapi/lib/jws_algorithms.js
var sig = [["verify"], ["sign"]];
function hmac(bits) {
  const subtle = { name: "HMAC", hash: `SHA-${bits}` };
  return { kty: ["oct"], secret: true, subtle, signing: subtle, usages: sig };
}
__name(hmac, "hmac");
function rsa(bits, saltLength) {
  const name = saltLength ? "RSA-PSS" : "RSASSA-PKCS1-v1_5";
  const subtle = { name, hash: `SHA-${bits}` };
  return {
    kty: ["RSA"],
    subtle,
    signing: saltLength ? { ...subtle, saltLength } : subtle,
    usages: sig,
    minRsaBits: 2048
  };
}
__name(rsa, "rsa");
function ecdsa(crv, bits) {
  return {
    kty: ["EC"],
    crv,
    subtle: { name: "ECDSA", namedCurve: crv },
    signing: { name: "ECDSA", hash: `SHA-${bits}` },
    usages: sig
  };
}
__name(ecdsa, "ecdsa");
function eddsa() {
  const subtle = { name: "Ed25519" };
  return {
    kty: ["OKP"],
    crv: "Ed25519",
    subtle,
    signing: subtle,
    usages: sig
  };
}
__name(eddsa, "eddsa");
function mldsa(bits) {
  const name = `ML-DSA-${bits}`;
  const subtle = { name };
  return {
    kty: ["AKP"],
    subtle,
    signing: subtle,
    usages: sig
  };
}
__name(mldsa, "mldsa");
var JWS = table({
  HS256: hmac(256),
  HS384: hmac(384),
  HS512: hmac(512),
  RS256: rsa(256),
  RS384: rsa(384),
  RS512: rsa(512),
  PS256: rsa(256, 32),
  PS384: rsa(384, 48),
  PS512: rsa(512, 64),
  ES256: ecdsa("P-256", 256),
  ES384: ecdsa("P-384", 384),
  ES512: ecdsa("P-521", 512),
  EdDSA: eddsa(),
  Ed25519: eddsa(),
  "ML-DSA-44": mldsa(44),
  "ML-DSA-65": mldsa(65),
  "ML-DSA-87": mldsa(87)
});
function jwsAlgorithm(alg) {
  const entry = typeof alg === "string" ? JWS[alg] : void 0;
  if (!entry) {
    throw new JOSENotSupported(`alg ${alg} is not supported either by JOSE or your javascript runtime`);
  }
  return entry;
}
__name(jwsAlgorithm, "jwsAlgorithm");

// node_modules/jose/dist/webapi/lib/jws_verify.js
function prepareVerify(options) {
  return [options && validateAlgorithms("algorithms", options.algorithms), options?.crit];
}
__name(prepareVerify, "prepareVerify");
async function verifySignature(jws, shared, key) {
  const { protected: encodedProtected, header, payload: inputPayload } = jws;
  let parsedProt = {};
  if (encodedProtected) {
    parsedProt = parseJoseHeader(encodedProtected, JWSInvalid, "JWS Protected Header is invalid");
  }
  let joseHeader;
  if (header !== void 0) {
    if (!isDisjoint(parsedProt, header)) {
      throw new JWSInvalid("JWS Protected and JWS Unprotected Header Parameter names must be disjoint");
    }
    joseHeader = { ...parsedProt, ...header };
  } else {
    joseHeader = parsedProt;
  }
  const extensions = validateCrit(JWSInvalid, JWS_RECOGNIZED, shared[1], parsedProt, joseHeader);
  let b64 = true;
  if (extensions.includes("b64")) {
    b64 = parsedProt.b64;
    if (typeof b64 !== "boolean") {
      throw new JWSInvalid('The "b64" (base64url-encode payload) Header Parameter must be a boolean');
    }
  }
  const { alg } = joseHeader;
  if (typeof alg !== "string" || !alg) {
    throw new JWSInvalid('JWS "alg" (Algorithm) Header Parameter missing or invalid');
  }
  if (shared[0] && !shared[0].has(alg)) {
    throw new JOSEAlgNotAllowed('"alg" (Algorithm) Header Parameter value not allowed');
  }
  if (b64) {
    if (typeof inputPayload !== "string") {
      throw new JWSInvalid("JWS Payload must be a string");
    }
  } else if (typeof inputPayload !== "string" && !(inputPayload instanceof Uint8Array)) {
    throw new JWSInvalid("JWS Payload must be a string or an Uint8Array instance");
  }
  let resolvedKey = false;
  if (typeof key === "function") {
    key = await key(parsedProt, jws);
    resolvedKey = true;
  }
  const entry = jwsAlgorithm(alg);
  const data = concat(encodedProtected !== void 0 ? encode(encodedProtected) : new Uint8Array(), encode("."), typeof inputPayload === "string" ? b64 ? shared[2] ??= encodeBase64url(inputPayload, "payload", JWSInvalid) : encoder.encode(inputPayload) : inputPayload);
  const signature = decodeBase64url(jws.signature, "signature", JWSInvalid);
  const k = await prepareKey(entry, key, "verify");
  const verified = await verify(entry, k, signature, data);
  if (!verified) {
    throw new JWSSignatureVerificationFailed();
  }
  let payload;
  if (b64) {
    payload = decodeBase64url(inputPayload, "payload", JWSInvalid);
  } else if (typeof inputPayload === "string") {
    payload = encoder.encode(inputPayload);
  } else {
    payload = inputPayload;
  }
  return [payload, parsedProt, b64, k, resolvedKey];
}
__name(verifySignature, "verifySignature");
async function verifyCompact(jws, shared, key) {
  if (jws instanceof Uint8Array) {
    jws = decoder.decode(jws);
  }
  if (typeof jws !== "string") {
    throw new JWSInvalid("Compact JWS must be a string or Uint8Array");
  }
  const { 0: protectedHeader, 1: payload, 2: signature, length } = jws.split(".");
  if (length !== 3) {
    throw new JWSInvalid("Invalid Compact JWS");
  }
  return verifySignature({ payload, protected: protectedHeader, signature }, shared, key);
}
__name(verifyCompact, "verifyCompact");

// node_modules/jose/dist/webapi/lib/jwt_claims_set.js
var epoch = /* @__PURE__ */ __name((date) => Math.floor(date.getTime() / 1e3), "epoch");
var multipliers = {
  s: 1,
  m: 60,
  h: 3600,
  d: 86400,
  w: 604800,
  y: 31557600
};
var REGEX = /^(\+|\-)? ?(\d+|\d+\.\d+) ?(seconds?|secs?|s|minutes?|mins?|m|hours?|hrs?|h|days?|d|weeks?|w|years?|yrs?|y)(?: (ago|from now))?$/i;
var checkFailed = "check_failed";
function secs(str) {
  const matched = REGEX.exec(str);
  if (!matched || matched[4] && matched[1]) {
    throw new TypeError("Invalid time period format");
  }
  const value = parseFloat(matched[2]);
  const numericDate = Math.round(value * multipliers[matched[3][0].toLowerCase()]);
  if (matched[1] === "-" || matched[4] === "ago") {
    return -numericDate;
  }
  return numericDate;
}
__name(secs, "secs");
function validateInput(label, input) {
  if (!Number.isFinite(input)) {
    throw new TypeError(`Invalid ${label} input`);
  }
  return input;
}
__name(validateInput, "validateInput");
var normalizeTyp = /* @__PURE__ */ __name((value) => {
  if (value.includes("/")) {
    return value.toLowerCase();
  }
  return `application/${value.toLowerCase()}`;
}, "normalizeTyp");
var checkAudiencePresence = /* @__PURE__ */ __name((audPayload, audOption) => {
  if (typeof audPayload === "string") {
    return audOption.includes(audPayload);
  }
  if (Array.isArray(audPayload)) {
    return audOption.some((aud) => audPayload.includes(aud));
  }
  return false;
}, "checkAudiencePresence");
function validateNumericDate(payload, claim, required = false) {
  const value = payload[claim];
  if (value === void 0 && !required)
    return void 0;
  if (typeof value !== "number") {
    throw new JWTClaimValidationFailed(`"${claim}" claim must be a number`, payload, claim, "invalid");
  }
  return value;
}
__name(validateNumericDate, "validateNumericDate");
function unexpectedClaim(payload, claim) {
  throw new JWTClaimValidationFailed(`unexpected "${claim}" claim value`, payload, claim, checkFailed);
}
__name(unexpectedClaim, "unexpectedClaim");
function validateClaimsSet(protectedHeader, encodedPayload, options = {}) {
  let payload;
  try {
    payload = JSON.parse(strictDecoder.decode(encodedPayload));
  } catch {
  }
  if (!isObject(payload)) {
    throw new JWTInvalid("JWT Claims Set must be a top-level JSON object");
  }
  const { typ } = options;
  if (typ && (typeof protectedHeader.typ !== "string" || normalizeTyp(protectedHeader.typ) !== normalizeTyp(typ))) {
    throw new JWTClaimValidationFailed('unexpected "typ" JWT header value', payload, "typ", checkFailed);
  }
  const { requiredClaims = [], issuer, subject, audience, maxTokenAge } = options;
  const presenceCheck = [...requiredClaims];
  if (maxTokenAge !== void 0)
    presenceCheck.push("iat");
  if (audience !== void 0)
    presenceCheck.push("aud");
  if (subject !== void 0)
    presenceCheck.push("sub");
  if (issuer !== void 0)
    presenceCheck.push("iss");
  for (const claim of new Set(presenceCheck.reverse())) {
    if (!Object.hasOwn(payload, claim)) {
      throw new JWTClaimValidationFailed(`missing required "${claim}" claim`, payload, claim, "missing");
    }
  }
  if (issuer !== void 0 && !(Array.isArray(issuer) ? issuer : [issuer]).includes(payload.iss)) {
    unexpectedClaim(payload, "iss");
  }
  if (subject !== void 0 && payload.sub !== subject) {
    unexpectedClaim(payload, "sub");
  }
  if (audience !== void 0 && !checkAudiencePresence(payload.aud, typeof audience === "string" ? [audience] : audience)) {
    unexpectedClaim(payload, "aud");
  }
  const { clockTolerance } = options;
  let tolerance = 0;
  if (typeof clockTolerance === "string") {
    tolerance = secs(clockTolerance);
  } else if (clockTolerance !== void 0) {
    if (typeof clockTolerance !== "number") {
      throw new TypeError("Invalid clockTolerance option type");
    }
    tolerance = clockTolerance;
  }
  validateInput("clockTolerance option", tolerance);
  const { currentDate } = options;
  const now = validateInput("currentDate option", epoch(currentDate || /* @__PURE__ */ new Date()));
  const iat = validateNumericDate(payload, "iat", maxTokenAge !== void 0);
  const nbf = validateNumericDate(payload, "nbf");
  if (nbf !== void 0) {
    if (nbf > now + tolerance) {
      throw new JWTClaimValidationFailed('"nbf" claim timestamp check failed', payload, "nbf", checkFailed);
    }
  }
  const exp = validateNumericDate(payload, "exp");
  if (exp !== void 0) {
    if (exp <= now - tolerance) {
      throw new JWTExpired('"exp" claim timestamp check failed', payload, "exp", checkFailed);
    }
  }
  if (maxTokenAge !== void 0) {
    const age = now - iat;
    const max = typeof maxTokenAge === "number" ? maxTokenAge : secs(maxTokenAge);
    if (age - tolerance > max) {
      throw new JWTExpired('"iat" claim timestamp check failed (too far in the past)', payload, "iat", checkFailed);
    }
    if (age < 0 - tolerance) {
      throw new JWTClaimValidationFailed('"iat" claim timestamp check failed (it should be in the past)', payload, "iat", checkFailed);
    }
  }
  return payload;
}
__name(validateClaimsSet, "validateClaimsSet");

// node_modules/jose/dist/webapi/jwt/verify.js
async function jwtVerify(jwt, key, options) {
  const verified = await verifyCompact(jwt, prepareVerify(options), key);
  if (!verified[2]) {
    throw new JWTInvalid("JWTs MUST NOT use unencoded payload");
  }
  const payload = validateClaimsSet(verified[1], verified[0], options);
  const result = { payload, protectedHeader: verified[1] };
  if (typeof key === "function") {
    return { ...result, key: verified[3] };
  }
  return result;
}
__name(jwtVerify, "jwtVerify");

// node_modules/jose/dist/webapi/jwks/local.js
function signatureAlgorithm(alg) {
  const entry = typeof alg === "string" ? JWS[alg] : void 0;
  if (!entry || entry.secret) {
    throw new JOSENotSupported('Unsupported "alg" value for a JSON Web Key Set');
  }
  return entry;
}
__name(signatureAlgorithm, "signatureAlgorithm");
function isJWKSLike(jwks2) {
  if (!jwks2 || typeof jwks2 !== "object") {
    return false;
  }
  const { keys } = jwks2;
  return Array.isArray(keys) && keys.every(isObject);
}
__name(isJWKSLike, "isJWKSLike");
var LocalJWKSetImpl = class {
  static {
    __name(this, "LocalJWKSetImpl");
  }
  #jwks;
  #cached = /* @__PURE__ */ new WeakMap();
  constructor(jwks2) {
    if (!isJWKSLike(jwks2)) {
      throw new JWKSInvalid("JSON Web Key Set malformed");
    }
    this.#jwks = structuredClone(jwks2);
  }
  jwks() {
    return this.#jwks;
  }
  async getKey(protectedHeader, token) {
    const { alg, kid } = { ...protectedHeader, ...token?.header };
    const entry = signatureAlgorithm(alg);
    const candidates = this.#jwks.keys.filter((jwk2) => entry.kty.includes(jwk2.kty) && (typeof kid !== "string" || kid === jwk2.kid) && (!(typeof jwk2.alg === "string" || jwk2.kty === "AKP") || alg === jwk2.alg) && (typeof jwk2.use !== "string" || jwk2.use === "sig") && (!Array.isArray(jwk2.key_ops) || jwk2.key_ops.includes("verify")) && (!entry.crv || jwk2.crv === entry.crv));
    const { 0: jwk, length } = candidates;
    if (length === 0) {
      throw new JWKSNoMatchingKey();
    }
    if (length !== 1) {
      const error = new JWKSMultipleMatchingKeys();
      const _cached = this.#cached;
      error[Symbol.asyncIterator] = async function* () {
        for (const jwk2 of candidates) {
          try {
            yield await importWithAlgCache(_cached, jwk2, entry);
          } catch {
          }
        }
      };
      throw error;
    }
    return importWithAlgCache(this.#cached, jwk, entry);
  }
};
async function importWithAlgCache(cache2, jwk, entry) {
  const cached2 = cache2.get(jwk) || cache2.set(jwk, { __proto__: null }).get(jwk);
  if (cached2[entry.alg] === void 0) {
    const key = await jwkToKey(entry, { ...jwk, alg: entry.alg, ext: true });
    if (key.type !== "public") {
      throw new JWKSInvalid("JSON Web Key Set members must be public keys");
    }
    cached2[entry.alg] = key;
  }
  return cached2[entry.alg];
}
__name(importWithAlgCache, "importWithAlgCache");
function createLocalJWKSet(jwks2) {
  const set = new LocalJWKSetImpl(jwks2);
  const localJWKSet = /* @__PURE__ */ __name(async (protectedHeader, token) => set.getKey(protectedHeader, token), "localJWKSet");
  Object.defineProperty(localJWKSet, "jwks", {
    value: /* @__PURE__ */ __name(() => structuredClone(set.jwks()), "value")
  });
  return localJWKSet;
}
__name(createLocalJWKSet, "createLocalJWKSet");

// node_modules/jose/dist/webapi/jwks/remote.js
function isCloudflareWorkers() {
  return typeof WebSocketPair !== "undefined" || typeof navigator !== "undefined" && true || typeof EdgeRuntime !== "undefined" && EdgeRuntime === "vercel";
}
__name(isCloudflareWorkers, "isCloudflareWorkers");
var USER_AGENT3;
if (typeof navigator === "undefined" || !"Cloudflare-Workers"?.startsWith?.("Mozilla/5.0 ")) {
  const NAME = "jose";
  const VERSION = "v6.2.8";
  USER_AGENT3 = `${NAME}/${VERSION}`;
}
var customFetch = /* @__PURE__ */ Symbol();
async function fetchJwks(url, headers, signal, fetchImpl = fetch) {
  const response = await fetchImpl(url, {
    method: "GET",
    signal,
    redirect: "manual",
    headers
  }).catch((err) => {
    if (err.name === "TimeoutError") {
      throw new JWKSTimeout();
    }
    throw err;
  });
  if (response.status !== 200) {
    throw new JOSEError("Expected 200 OK from the JSON Web Key Set HTTP response");
  }
  try {
    return await response.json();
  } catch {
    throw new JOSEError("Failed to parse the JSON Web Key Set HTTP response as JSON");
  }
}
__name(fetchJwks, "fetchJwks");
var jwksCache = /* @__PURE__ */ Symbol();
function isFreshJwksCache(input, cacheMaxAge) {
  if (typeof input !== "object" || input === null) {
    return false;
  }
  if (!("uat" in input) || typeof input.uat !== "number" || Date.now() - input.uat >= cacheMaxAge) {
    return false;
  }
  if (!("jwks" in input) || !isObject(input.jwks) || !Array.isArray(input.jwks.keys) || !Array.prototype.every.call(input.jwks.keys, isObject)) {
    return false;
  }
  return true;
}
__name(isFreshJwksCache, "isFreshJwksCache");
var RemoteJWKSetImpl = class {
  static {
    __name(this, "RemoteJWKSetImpl");
  }
  #url;
  #timeoutDuration;
  #cooldownDuration;
  #cacheMaxAge;
  #jwksTimestamp;
  #pendingFetch;
  #headers;
  #customFetch;
  #local;
  #cache;
  constructor(url, options) {
    if (!(url instanceof URL)) {
      throw new TypeError("url must be an instance of URL");
    }
    this.#url = new URL(url.href);
    const opts = options ?? {};
    this.#timeoutDuration = typeof opts.timeoutDuration === "number" ? opts.timeoutDuration : 5e3;
    this.#cooldownDuration = typeof opts.cooldownDuration === "number" ? opts.cooldownDuration : 3e4;
    this.#cacheMaxAge = typeof opts.cacheMaxAge === "number" ? opts.cacheMaxAge : 6e5;
    this.#headers = new Headers(opts.headers);
    if (USER_AGENT3 && !this.#headers.has("User-Agent")) {
      this.#headers.set("User-Agent", USER_AGENT3);
    }
    if (!this.#headers.has("accept")) {
      this.#headers.set("accept", "application/json");
      this.#headers.append("accept", "application/jwk-set+json");
    }
    this.#customFetch = opts[customFetch];
    const cache2 = opts[jwksCache];
    if (cache2 !== void 0) {
      this.#cache = cache2;
      if (isFreshJwksCache(cache2, this.#cacheMaxAge)) {
        this.#jwksTimestamp = this.#cache.uat;
        this.#local = createLocalJWKSet(this.#cache.jwks);
      }
    }
  }
  pendingFetch() {
    return !!this.#pendingFetch;
  }
  #validFor(duration) {
    return typeof this.#jwksTimestamp === "number" && Date.now() < this.#jwksTimestamp + duration;
  }
  coolingDown() {
    return this.#validFor(this.#cooldownDuration);
  }
  fresh() {
    return this.#validFor(this.#cacheMaxAge);
  }
  jwks() {
    return this.#local?.jwks();
  }
  async getKey(protectedHeader, token) {
    if (!this.#local || !this.fresh()) {
      await this.reload();
    }
    try {
      return await this.#local(protectedHeader, token);
    } catch (err) {
      if (err instanceof JWKSNoMatchingKey) {
        if (this.coolingDown() === false) {
          await this.reload();
          return this.#local(protectedHeader, token);
        }
      }
      throw err;
    }
  }
  async reload() {
    if (this.#pendingFetch && isCloudflareWorkers()) {
      this.#pendingFetch = void 0;
    }
    this.#pendingFetch ||= fetchJwks(this.#url.href, this.#headers, AbortSignal.timeout(this.#timeoutDuration), this.#customFetch).then((json2) => {
      this.#local = createLocalJWKSet(json2);
      if (this.#cache) {
        this.#cache.uat = Date.now();
        this.#cache.jwks = json2;
      }
      this.#jwksTimestamp = Date.now();
    }).finally(() => {
      this.#pendingFetch = void 0;
    });
    await this.#pendingFetch;
  }
};
function createRemoteJWKSet(url, options) {
  const set = new RemoteJWKSetImpl(url, options);
  const remoteJWKSet = /* @__PURE__ */ __name(async (protectedHeader, token) => set.getKey(protectedHeader, token), "remoteJWKSet");
  Object.defineProperties(remoteJWKSet, {
    coolingDown: {
      get: /* @__PURE__ */ __name(() => set.coolingDown(), "get"),
      enumerable: true
    },
    fresh: {
      get: /* @__PURE__ */ __name(() => set.fresh(), "get"),
      enumerable: true
    },
    reload: {
      value: /* @__PURE__ */ __name(() => set.reload(), "value"),
      enumerable: true
    },
    reloading: {
      get: /* @__PURE__ */ __name(() => set.pendingFetch(), "get"),
      enumerable: true
    },
    jwks: {
      value: /* @__PURE__ */ __name(() => set.jwks(), "value"),
      enumerable: true
    }
  });
  return remoteJWKSet;
}
__name(createRemoteJWKSet, "createRemoteJWKSet");

// src/firebaseAuth.ts
var jwks = createRemoteJWKSet(
  new URL("https://www.googleapis.com/service_accounts/v1/jwk/securetoken@system.gserviceaccount.com")
);
async function verifyFirebaseIdToken(env, authHeader) {
  if (!authHeader?.startsWith("Bearer ")) {
    throw new Error("Missing Bearer token");
  }
  const token = authHeader.slice("Bearer ".length);
  const projectId = env.FIREBASE_PROJECT_ID;
  const { payload } = await jwtVerify(token, jwks, {
    issuer: `https://securetoken.google.com/${projectId}`,
    audience: projectId
  });
  const uid = payload.sub;
  if (!uid || typeof uid !== "string") throw new Error("Invalid token subject");
  return {
    uid,
    email: typeof payload.email === "string" ? payload.email : void 0
  };
}
__name(verifyFirebaseIdToken, "verifyFirebaseIdToken");

// src/firestore.ts
function pemToArrayBuffer(pem) {
  const b64 = pem.replace(/-----BEGIN PRIVATE KEY-----/, "").replace(/-----END PRIVATE KEY-----/, "").replace(/\s+/g, "");
  const raw = atob(b64);
  const buf = new Uint8Array(raw.length);
  for (let i = 0; i < raw.length; i += 1) buf[i] = raw.charCodeAt(i);
  return buf.buffer;
}
__name(pemToArrayBuffer, "pemToArrayBuffer");
function base64url(data) {
  const bytes = typeof data === "string" ? new TextEncoder().encode(data) : new Uint8Array(data);
  let str = "";
  for (const b of bytes) str += String.fromCharCode(b);
  return btoa(str).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
}
__name(base64url, "base64url");
async function getAccessToken(sa) {
  const now = Math.floor(Date.now() / 1e3);
  const header = { alg: "RS256", typ: "JWT" };
  const claim = {
    iss: sa.client_email,
    scope: "https://www.googleapis.com/auth/datastore",
    aud: sa.token_uri || "https://oauth2.googleapis.com/token",
    iat: now,
    exp: now + 3600
  };
  const unsigned = `${base64url(JSON.stringify(header))}.${base64url(JSON.stringify(claim))}`;
  const key = await crypto.subtle.importKey(
    "pkcs8",
    pemToArrayBuffer(sa.private_key),
    { name: "RSASSA-PKCS1-v1_5", hash: "SHA-256" },
    false,
    ["sign"]
  );
  const signature = await crypto.subtle.sign(
    "RSASSA-PKCS1-v1_5",
    key,
    new TextEncoder().encode(unsigned)
  );
  const jwt = `${unsigned}.${base64url(signature)}`;
  const body = new URLSearchParams({
    grant_type: "urn:ietf:params:oauth:grant-type:jwt-bearer",
    assertion: jwt
  });
  const res = await fetch(sa.token_uri || "https://oauth2.googleapis.com/token", {
    method: "POST",
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body
  });
  const json2 = await res.json();
  if (!res.ok || !json2.access_token) {
    throw new Error(`Service account token failed: ${json2.error || res.status}`);
  }
  return json2.access_token;
}
__name(getAccessToken, "getAccessToken");
function parseServiceAccount(env) {
  if (!env.FIREBASE_SERVICE_ACCOUNT) return null;
  try {
    return JSON.parse(env.FIREBASE_SERVICE_ACCOUNT);
  } catch {
    throw new Error("FIREBASE_SERVICE_ACCOUNT is not valid JSON");
  }
}
__name(parseServiceAccount, "parseServiceAccount");
async function upsertSubscriptionAndPlan(env, input) {
  const sa = parseServiceAccount(env);
  if (!sa) {
    console.warn("[firestore] FIREBASE_SERVICE_ACCOUNT missing \u2014 webhook verified but not persisted");
    return;
  }
  const projectId = sa.project_id || env.FIREBASE_PROJECT_ID;
  const token = await getAccessToken(sa);
  const now = (/* @__PURE__ */ new Date()).toISOString();
  const subUrl = `https://firestore.googleapis.com/v1/projects/${projectId}/databases/(default)/documents/subscriptions/${input.uid}`;
  const userUrl = `https://firestore.googleapis.com/v1/projects/${projectId}/databases/(default)/documents/users/${input.uid}?updateMask.fieldPaths=plan&updateMask.fieldPaths=updatedAt`;
  const subBody = {
    fields: {
      userId: { stringValue: input.uid },
      status: { stringValue: input.status },
      plan: { stringValue: input.plan },
      ...input.stripeCustomerId ? { stripeCustomerId: { stringValue: input.stripeCustomerId } } : {},
      ...input.stripeSubscriptionId ? { stripeSubscriptionId: { stringValue: input.stripeSubscriptionId } } : {},
      updatedAt: { timestampValue: now }
    }
  };
  const userBody = {
    fields: {
      plan: { stringValue: input.plan },
      updatedAt: { timestampValue: now }
    }
  };
  const [subRes, userRes] = await Promise.all([
    fetch(subUrl, {
      method: "PATCH",
      headers: {
        Authorization: `Bearer ${token}`,
        "Content-Type": "application/json"
      },
      body: JSON.stringify(subBody)
    }),
    fetch(userUrl, {
      method: "PATCH",
      headers: {
        Authorization: `Bearer ${token}`,
        "Content-Type": "application/json"
      },
      body: JSON.stringify(userBody)
    })
  ]);
  if (!subRes.ok) {
    const t = await subRes.text();
    throw new Error(`subscriptions write failed: ${subRes.status} ${t.slice(0, 300)}`);
  }
  if (!userRes.ok) {
    const t = await userRes.text();
    throw new Error(`users.plan write failed: ${userRes.status} ${t.slice(0, 300)}`);
  }
}
__name(upsertSubscriptionAndPlan, "upsertSubscriptionAndPlan");
async function readSubscriptionCustomerId(env, uid) {
  const sa = parseServiceAccount(env);
  if (!sa) return void 0;
  const projectId = sa.project_id || env.FIREBASE_PROJECT_ID;
  const token = await getAccessToken(sa);
  const url = `https://firestore.googleapis.com/v1/projects/${projectId}/databases/(default)/documents/subscriptions/${uid}`;
  const res = await fetch(url, { headers: { Authorization: `Bearer ${token}` } });
  if (!res.ok) return void 0;
  const json2 = await res.json();
  return json2.fields?.stripeCustomerId?.stringValue;
}
__name(readSubscriptionCustomerId, "readSubscriptionCustomerId");
async function readUserEntitlements(env, uid) {
  const sa = parseServiceAccount(env);
  if (!sa) return null;
  const projectId = sa.project_id || env.FIREBASE_PROJECT_ID;
  const token = await getAccessToken(sa);
  const url = `https://firestore.googleapis.com/v1/projects/${projectId}/databases/(default)/documents/users/${uid}`;
  const res = await fetch(url, { headers: { Authorization: `Bearer ${token}` } });
  if (res.status === 404) return { plan: "free", routesSaved: 0 };
  if (!res.ok) return null;
  const json2 = await res.json();
  const planRaw = json2.fields?.plan?.stringValue;
  const plan = planRaw === "premium" ? "premium" : "free";
  const savedField = json2.fields?.usage?.mapValue?.fields?.routesSaved;
  const routesSaved = Number(savedField?.integerValue ?? savedField?.doubleValue ?? 0) || 0;
  return { plan, routesSaved };
}
__name(readUserEntitlements, "readUserEntitlements");
async function writeUserPlan(env, uid, plan) {
  const sa = parseServiceAccount(env);
  if (!sa) {
    console.warn("[firestore] FIREBASE_SERVICE_ACCOUNT missing \u2014 plan not persisted");
    return;
  }
  const projectId = sa.project_id || env.FIREBASE_PROJECT_ID;
  const token = await getAccessToken(sa);
  const now = (/* @__PURE__ */ new Date()).toISOString();
  const userUrl = `https://firestore.googleapis.com/v1/projects/${projectId}/databases/(default)/documents/users/${uid}?updateMask.fieldPaths=plan&updateMask.fieldPaths=updatedAt`;
  const res = await fetch(userUrl, {
    method: "PATCH",
    headers: {
      Authorization: `Bearer ${token}`,
      "Content-Type": "application/json"
    },
    body: JSON.stringify({
      fields: {
        plan: { stringValue: plan },
        updatedAt: { timestampValue: now }
      }
    })
  });
  if (!res.ok) {
    const t = await res.text();
    throw new Error(`users.plan write failed: ${res.status} ${t.slice(0, 300)}`);
  }
}
__name(writeUserPlan, "writeUserPlan");
async function writeSubscriptionCustomerId(env, uid, customerId) {
  const sa = parseServiceAccount(env);
  if (!sa) {
    console.warn("[firestore] FIREBASE_SERVICE_ACCOUNT missing \u2014 customer id not persisted");
    return;
  }
  const projectId = sa.project_id || env.FIREBASE_PROJECT_ID;
  const token = await getAccessToken(sa);
  const now = (/* @__PURE__ */ new Date()).toISOString();
  const subUrl = `https://firestore.googleapis.com/v1/projects/${projectId}/databases/(default)/documents/subscriptions/${uid}?updateMask.fieldPaths=userId&updateMask.fieldPaths=stripeCustomerId&updateMask.fieldPaths=updatedAt`;
  const res = await fetch(subUrl, {
    method: "PATCH",
    headers: {
      Authorization: `Bearer ${token}`,
      "Content-Type": "application/json"
    },
    body: JSON.stringify({
      fields: {
        userId: { stringValue: uid },
        stripeCustomerId: { stringValue: customerId },
        updatedAt: { timestampValue: now }
      }
    })
  });
  if (!res.ok) {
    const t = await res.text();
    throw new Error(`subscriptions customer write failed: ${res.status} ${t.slice(0, 300)}`);
  }
}
__name(writeSubscriptionCustomerId, "writeSubscriptionCustomerId");
async function readStravaConnection(env, uid) {
  const sa = parseServiceAccount(env);
  if (!sa) return null;
  const projectId = sa.project_id || env.FIREBASE_PROJECT_ID;
  const token = await getAccessToken(sa);
  const url = `https://firestore.googleapis.com/v1/projects/${projectId}/databases/(default)/documents/stravaConnections/${uid}`;
  const res = await fetch(url, { headers: { Authorization: `Bearer ${token}` } });
  if (!res.ok) return null;
  const json2 = await res.json();
  const accessToken = json2.fields?.accessToken?.stringValue;
  const refreshToken = json2.fields?.refreshToken?.stringValue;
  const expiresAt = Number(
    json2.fields?.expiresAt?.integerValue ?? json2.fields?.expiresAt?.doubleValue ?? 0
  );
  const athleteId = Number(
    json2.fields?.athleteId?.integerValue ?? json2.fields?.athleteId?.doubleValue ?? 0
  );
  if (!accessToken || !refreshToken || !expiresAt) return null;
  return {
    athleteId,
    accessToken,
    refreshToken,
    expiresAt,
    scope: json2.fields?.scope?.stringValue
  };
}
__name(readStravaConnection, "readStravaConnection");
async function writeStravaConnection(env, uid, conn) {
  const sa = parseServiceAccount(env);
  if (!sa) {
    console.warn("[firestore] FIREBASE_SERVICE_ACCOUNT missing \u2014 Strava tokens not persisted");
    return;
  }
  const projectId = sa.project_id || env.FIREBASE_PROJECT_ID;
  const token = await getAccessToken(sa);
  const now = (/* @__PURE__ */ new Date()).toISOString();
  const url = `https://firestore.googleapis.com/v1/projects/${projectId}/databases/(default)/documents/stravaConnections/${uid}?updateMask.fieldPaths=athleteId&updateMask.fieldPaths=accessToken&updateMask.fieldPaths=refreshToken&updateMask.fieldPaths=expiresAt&updateMask.fieldPaths=scope&updateMask.fieldPaths=updatedAt`;
  const res = await fetch(url, {
    method: "PATCH",
    headers: {
      Authorization: `Bearer ${token}`,
      "Content-Type": "application/json"
    },
    body: JSON.stringify({
      fields: {
        athleteId: { integerValue: String(conn.athleteId) },
        accessToken: { stringValue: conn.accessToken },
        refreshToken: { stringValue: conn.refreshToken },
        expiresAt: { integerValue: String(Math.floor(conn.expiresAt)) },
        ...conn.scope ? { scope: { stringValue: conn.scope } } : {},
        updatedAt: { timestampValue: now }
      }
    })
  });
  if (!res.ok) {
    const t = await res.text();
    throw new Error(`stravaConnections write failed: ${res.status} ${t.slice(0, 300)}`);
  }
}
__name(writeStravaConnection, "writeStravaConnection");
async function deleteStravaConnection(env, uid) {
  const sa = parseServiceAccount(env);
  if (!sa) return;
  const projectId = sa.project_id || env.FIREBASE_PROJECT_ID;
  const token = await getAccessToken(sa);
  const url = `https://firestore.googleapis.com/v1/projects/${projectId}/databases/(default)/documents/stravaConnections/${uid}`;
  await fetch(url, { method: "DELETE", headers: { Authorization: `Bearer ${token}` } });
}
__name(deleteStravaConnection, "deleteStravaConnection");

// src/stripe.ts
async function stripeForm(env, path, params) {
  const body = new URLSearchParams(params);
  return fetch(`https://api.stripe.com/v1/${path}`, {
    method: "POST",
    headers: {
      Authorization: `Bearer ${env.STRIPE_SECRET_KEY}`,
      "Content-Type": "application/x-www-form-urlencoded"
    },
    body
  });
}
__name(stripeForm, "stripeForm");
async function stripeGet(env, path) {
  return fetch(`https://api.stripe.com/v1/${path}`, {
    headers: { Authorization: `Bearer ${env.STRIPE_SECRET_KEY}` }
  });
}
__name(stripeGet, "stripeGet");
async function handleCheckout(request, env) {
  if (!env.STRIPE_SECRET_KEY) return json({ error: "Stripe secret missing" }, 500);
  const identity = await verifyFirebaseIdToken(env, request.headers.get("Authorization"));
  const payload = await request.json().catch(() => ({}));
  const interval = payload.interval === "year" ? "year" : "month";
  const priceId = interval === "year" ? env.STRIPE_PRICE_YEARLY : env.STRIPE_PRICE_MONTHLY;
  if (!priceId) return json({ error: "Price id not configured" }, 500);
  let customerId = await readSubscriptionCustomerId(env, identity.uid);
  if (!customerId) {
    const customerRes = await stripeForm(env, "customers", {
      ...identity.email ? { email: identity.email } : {},
      "metadata[firebaseUid]": identity.uid
    });
    const customer = await customerRes.json();
    if (!customerRes.ok || !customer.id) {
      return json({ error: customer.error?.message || "Could not create Stripe customer" }, 502);
    }
    customerId = customer.id;
    await writeSubscriptionCustomerId(env, identity.uid, customerId);
  }
  const appUrl = resolveAppUrl(env, request);
  const sessionRes = await stripeForm(env, "checkout/sessions", {
    mode: "subscription",
    customer: customerId,
    "line_items[0][price]": priceId,
    "line_items[0][quantity]": "1",
    success_url: `${appUrl}/premium?checkout=success`,
    cancel_url: `${appUrl}/premium?checkout=cancel`,
    "metadata[firebaseUid]": identity.uid,
    "subscription_data[metadata][firebaseUid]": identity.uid,
    allow_promotion_codes: "true"
  });
  const session = await sessionRes.json();
  if (!sessionRes.ok || !session.url) {
    return json({ error: session.error?.message || "Checkout session failed" }, 502);
  }
  return json({ url: session.url });
}
__name(handleCheckout, "handleCheckout");
async function handlePortal(request, env) {
  if (!env.STRIPE_SECRET_KEY) return json({ error: "Stripe secret missing" }, 500);
  const identity = await verifyFirebaseIdToken(env, request.headers.get("Authorization"));
  const customerId = await readSubscriptionCustomerId(env, identity.uid);
  if (!customerId) return json({ error: "No Stripe customer for this user" }, 400);
  const portalRes = await stripeForm(env, "billing_portal/sessions", {
    customer: customerId,
    return_url: `${resolveAppUrl(env, request)}/premium`
  });
  const portal = await portalRes.json();
  if (!portalRes.ok || !portal.url) {
    return json({ error: portal.error?.message || "Portal session failed" }, 502);
  }
  return json({ url: portal.url });
}
__name(handlePortal, "handlePortal");
async function hmacSha256(secret, payload) {
  const key = await crypto.subtle.importKey(
    "raw",
    new TextEncoder().encode(secret),
    { name: "HMAC", hash: "SHA-256" },
    false,
    ["sign"]
  );
  return crypto.subtle.sign("HMAC", key, new TextEncoder().encode(payload));
}
__name(hmacSha256, "hmacSha256");
function timingSafeEqual(a, b) {
  if (a.length !== b.length) return false;
  let out = 0;
  for (let i = 0; i < a.length; i += 1) out |= a.charCodeAt(i) ^ b.charCodeAt(i);
  return out === 0;
}
__name(timingSafeEqual, "timingSafeEqual");
function toHex(buf) {
  return [...new Uint8Array(buf)].map((b) => b.toString(16).padStart(2, "0")).join("");
}
__name(toHex, "toHex");
async function verifyStripeSignature(payload, header, secret) {
  if (!header) return false;
  const parts = Object.fromEntries(
    header.split(",").map((p) => {
      const [k, v] = p.split("=");
      return [k.trim(), v];
    })
  );
  if (!parts.t || !parts.v1) return false;
  const signed = `${parts.t}.${payload}`;
  const digest = toHex(await hmacSha256(secret, signed));
  const candidates = header.split(",").filter((p) => p.trim().startsWith("v1=")).map((p) => p.trim().slice(3));
  return candidates.some((sig2) => timingSafeEqual(sig2, digest));
}
__name(verifyStripeSignature, "verifyStripeSignature");
async function handleWebhook(request, env) {
  if (!env.STRIPE_SECRET_KEY) return json({ error: "Stripe secret missing" }, 500);
  const payload = await request.text();
  const signature = request.headers.get("Stripe-Signature");
  if (env.STRIPE_WEBHOOK_SECRET) {
    const ok = await verifyStripeSignature(payload, signature, env.STRIPE_WEBHOOK_SECRET);
    if (!ok) return json({ error: "Invalid signature" }, 400);
  } else {
    console.error("[stripe] STRIPE_WEBHOOK_SECRET missing \u2014 rejecting webhook");
    return json({ error: "Webhook secret not configured" }, 500);
  }
  const event = JSON.parse(payload);
  try {
    if (event.type === "checkout.session.completed" || event.type === "customer.subscription.created" || event.type === "customer.subscription.updated") {
      const obj = event.data.object;
      const metadata = obj.metadata || {};
      let uid = metadata.firebaseUid;
      const customerId = typeof obj.customer === "string" ? obj.customer : void 0;
      const subscriptionId = typeof obj.subscription === "string" ? obj.subscription : typeof obj.id === "string" && event.type.startsWith("customer.subscription") ? obj.id : void 0;
      if (!uid && subscriptionId) {
        const subRes = await stripeGet(env, `subscriptions/${subscriptionId}`);
        const sub = await subRes.json();
        uid = sub.metadata?.firebaseUid;
      }
      if (!uid && customerId) {
        const custRes = await stripeGet(env, `customers/${customerId}`);
        const cust = await custRes.json();
        uid = cust.metadata?.firebaseUid;
      }
      if (!uid) {
        console.warn("[stripe] missing firebaseUid", event.type);
        return json({ received: true, warning: "missing firebaseUid" });
      }
      const status = event.type === "checkout.session.completed" ? "active" : String(obj.status || "active");
      const plan = status === "active" || status === "trialing" ? "premium" : "free";
      await upsertSubscriptionAndPlan(env, {
        uid,
        plan,
        status,
        stripeCustomerId: customerId,
        stripeSubscriptionId: subscriptionId
      });
    }
    if (event.type === "customer.subscription.deleted") {
      const obj = event.data.object;
      const metadata = obj.metadata || {};
      let uid = metadata.firebaseUid;
      const customerId = typeof obj.customer === "string" ? obj.customer : void 0;
      if (!uid && customerId) {
        const custRes = await stripeGet(env, `customers/${customerId}`);
        const cust = await custRes.json();
        uid = cust.metadata?.firebaseUid;
      }
      if (uid) {
        await upsertSubscriptionAndPlan(env, {
          uid,
          plan: "free",
          status: "canceled",
          stripeCustomerId: customerId,
          stripeSubscriptionId: typeof obj.id === "string" ? obj.id : void 0
        });
      }
    }
  } catch (error) {
    console.error("[stripe webhook]", error);
    return json({ error: "Webhook handler failed" }, 500);
  }
  return json({ received: true });
}
__name(handleWebhook, "handleWebhook");

// src/rateLimit.ts
var memoryBuckets = /* @__PURE__ */ new Map();
function memoryBump(key, limit, windowSec) {
  const now = Date.now();
  const hit = memoryBuckets.get(key);
  if (!hit || hit.expiresAt <= now) {
    memoryBuckets.set(key, { count: 1, expiresAt: now + windowSec * 1e3 });
    return true;
  }
  if (hit.count >= limit) return false;
  hit.count += 1;
  return true;
}
__name(memoryBump, "memoryBump");
function limitedResponse(windowSec) {
  return json(
    {
      error: "Too many requests",
      code: "rate_limited",
      retryAfterSec: windowSec
    },
    429,
    { "Retry-After": String(windowSec) }
  );
}
__name(limitedResponse, "limitedResponse");
async function enforceRateLimit(request, opts) {
  const id = opts.key || request.headers.get("CF-Connecting-IP") || request.headers.get("x-forwarded-for") || "unknown";
  const bucket = Math.floor(Date.now() / (opts.windowSec * 1e3));
  const memKey = `${opts.prefix}:${id}:${bucket}`;
  const cacheKey = new Request(
    `https://pedalmap-rl.internal/${opts.prefix}/${encodeURIComponent(id)}/${bucket}`
  );
  try {
    const cache2 = caches.default;
    const hit = await cache2.match(cacheKey);
    let count = 0;
    if (hit) {
      count = Number(await hit.text()) || 0;
    }
    if (count >= opts.limit) {
      return limitedResponse(opts.windowSec);
    }
    count += 1;
    await cache2.put(
      cacheKey,
      new Response(String(count), {
        headers: {
          "Cache-Control": `max-age=${opts.windowSec}`,
          "Content-Type": "text/plain"
        }
      })
    );
  } catch (error) {
    console.warn("[rateLimit] cache failed \u2014 using memory bucket", error);
    if (!memoryBump(memKey, opts.limit, opts.windowSec)) {
      return limitedResponse(opts.windowSec);
    }
  }
  return null;
}
__name(enforceRateLimit, "enforceRateLimit");

// src/premiumAllowlist.ts
var DEFAULT_PREMIUM_EMAILS = ["rayvf2002@gmail.com", "raymel.vb@gmail.com"];
function premiumAllowlistEmails(env) {
  const raw = (env.PREMIUM_ALLOWLIST || "").trim();
  const list = raw ? raw.split(",").map((s) => s.trim().toLowerCase()).filter(Boolean) : DEFAULT_PREMIUM_EMAILS.map((e) => e.toLowerCase());
  return new Set(list);
}
__name(premiumAllowlistEmails, "premiumAllowlistEmails");
function isAllowlistedPremiumEmail(env, email) {
  if (!email) return false;
  return premiumAllowlistEmails(env).has(email.trim().toLowerCase());
}
__name(isAllowlistedPremiumEmail, "isAllowlistedPremiumEmail");

// src/entitlements.ts
var FREE_MAX_SAVED = 5;
async function handleSyncPlan(env, identity) {
  const email = identity.email ?? null;
  const allowlisted = isAllowlistedPremiumEmail(env, email);
  const current = await readUserEntitlements(env, identity.uid);
  let plan = current?.plan ?? "free";
  if (allowlisted && plan !== "premium") {
    await writeUserPlan(env, identity.uid, "premium");
    plan = "premium";
  }
  return json({
    ok: true,
    uid: identity.uid,
    email,
    plan,
    allowlisted,
    gpxExport: plan === "premium",
    maxRoutesSaved: plan === "premium" ? null : FREE_MAX_SAVED,
    routesSaved: current?.routesSaved ?? 0
  });
}
__name(handleSyncPlan, "handleSyncPlan");
async function handleEntitlements(env, identity) {
  const email = identity.email ?? null;
  const allowlisted = isAllowlistedPremiumEmail(env, email);
  const current = await readUserEntitlements(env, identity.uid);
  const plan = allowlisted || current?.plan === "premium" ? "premium" : "free";
  if (allowlisted && current?.plan !== "premium") {
    try {
      await writeUserPlan(env, identity.uid, "premium");
    } catch (error) {
      console.warn("[entitlements] allowlist sync failed", error);
    }
  }
  return json({
    ok: true,
    uid: identity.uid,
    email,
    plan,
    allowlisted,
    gpxExport: plan === "premium",
    maxRoutesSaved: plan === "premium" ? null : FREE_MAX_SAVED,
    routesSaved: current?.routesSaved ?? 0,
    canSaveRoute: plan === "premium" || (current?.routesSaved ?? 0) < FREE_MAX_SAVED
  });
}
__name(handleEntitlements, "handleEntitlements");

// src/strava.ts
var STRAVA_AUTH = "https://www.strava.com/oauth/authorize";
var STRAVA_TOKEN = "https://www.strava.com/oauth/token";
var STRAVA_API = "https://www.strava.com/api/v3";
var SCOPE = "read,activity:read_all,profile:read_all";
function stravaConfigured(env) {
  return Boolean(env.STRAVA_CLIENT_ID && env.STRAVA_CLIENT_SECRET);
}
__name(stravaConfigured, "stravaConfigured");
function redirectUri(env, request) {
  const workerOrigin = new URL(request.url).origin;
  return `${workerOrigin}/strava/oauth/callback`;
}
__name(redirectUri, "redirectUri");
function b64url(input) {
  const bytes = new TextEncoder().encode(input);
  let bin = "";
  for (const b of bytes) bin += String.fromCharCode(b);
  return btoa(bin).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
}
__name(b64url, "b64url");
function fromB64url(input) {
  const pad = input.length % 4 === 0 ? "" : "=".repeat(4 - input.length % 4);
  const b64 = input.replace(/-/g, "+").replace(/_/g, "/") + pad;
  const raw = atob(b64);
  const bytes = new Uint8Array(raw.length);
  for (let i = 0; i < raw.length; i += 1) bytes[i] = raw.charCodeAt(i);
  return new TextDecoder().decode(bytes);
}
__name(fromB64url, "fromB64url");
async function hmacSign(secret, payload) {
  const key = await crypto.subtle.importKey(
    "raw",
    new TextEncoder().encode(secret),
    { name: "HMAC", hash: "SHA-256" },
    false,
    ["sign"]
  );
  const sig2 = await crypto.subtle.sign("HMAC", key, new TextEncoder().encode(payload));
  const bytes = new Uint8Array(sig2);
  let bin = "";
  for (const b of bytes) bin += String.fromCharCode(b);
  return btoa(bin).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
}
__name(hmacSign, "hmacSign");
async function makeState(env, uid) {
  const exp = Math.floor(Date.now() / 1e3) + 600;
  const body = `${uid}.${exp}`;
  const sig2 = await hmacSign(env.STRAVA_CLIENT_SECRET, body);
  return `${b64url(body)}.${sig2}`;
}
__name(makeState, "makeState");
async function parseState(env, state) {
  const [bodyB64, sig2] = state.split(".");
  if (!bodyB64 || !sig2) return null;
  const body = fromB64url(bodyB64);
  const expect = await hmacSign(env.STRAVA_CLIENT_SECRET, body);
  if (expect !== sig2) return null;
  const [uid, expRaw] = body.split(".");
  const exp = Number(expRaw);
  if (!uid || !Number.isFinite(exp) || exp < Math.floor(Date.now() / 1e3)) return null;
  return uid;
}
__name(parseState, "parseState");
async function handleStravaOAuthStart(request, env, identity) {
  if (!stravaConfigured(env)) {
    return json(
      {
        error: "Strava no configurado",
        code: "strava_not_configured",
        hint: "wrangler secret put STRAVA_CLIENT_ID / STRAVA_CLIENT_SECRET"
      },
      503
    );
  }
  if (identity.uid.startsWith("anonymous") || !identity.email) {
  }
  const state = await makeState(env, identity.uid);
  const params = new URLSearchParams({
    client_id: env.STRAVA_CLIENT_ID,
    response_type: "code",
    redirect_uri: redirectUri(env, request),
    approval_prompt: "auto",
    scope: SCOPE,
    state
  });
  return json({ ok: true, url: `${STRAVA_AUTH}?${params}` });
}
__name(handleStravaOAuthStart, "handleStravaOAuthStart");
async function handleStravaOAuthCallback(request, env) {
  const appUrl = (env.APP_URL || "https://pedalmap-79b3a.web.app").replace(/\/+$/, "");
  if (!stravaConfigured(env)) {
    return Response.redirect(`${appUrl}/actividades?strava=error&reason=not_configured`, 302);
  }
  const url = new URL(request.url);
  const err = url.searchParams.get("error");
  if (err) {
    return Response.redirect(`${appUrl}/actividades?strava=error&reason=${encodeURIComponent(err)}`, 302);
  }
  const code = url.searchParams.get("code");
  const state = url.searchParams.get("state");
  if (!code || !state) {
    return Response.redirect(`${appUrl}/actividades?strava=error&reason=missing_code`, 302);
  }
  const uid = await parseState(env, state);
  if (!uid) {
    return Response.redirect(`${appUrl}/actividades?strava=error&reason=bad_state`, 302);
  }
  const tokenRes = await fetch(STRAVA_TOKEN, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      client_id: Number(env.STRAVA_CLIENT_ID),
      client_secret: env.STRAVA_CLIENT_SECRET,
      code,
      grant_type: "authorization_code"
    })
  });
  const tokenJson = await tokenRes.json();
  if (!tokenRes.ok || !tokenJson.access_token || !tokenJson.refresh_token || !tokenJson.expires_at) {
    console.error("[strava] token exchange", tokenJson);
    return Response.redirect(`${appUrl}/actividades?strava=error&reason=token`, 302);
  }
  await writeStravaConnection(env, uid, {
    athleteId: tokenJson.athlete?.id ?? 0,
    accessToken: tokenJson.access_token,
    refreshToken: tokenJson.refresh_token,
    expiresAt: tokenJson.expires_at,
    scope: SCOPE
  });
  return Response.redirect(`${appUrl}/actividades?strava=connected`, 302);
}
__name(handleStravaOAuthCallback, "handleStravaOAuthCallback");
async function refreshIfNeeded(env, uid, conn) {
  const skew = 60;
  if (conn.expiresAt > Math.floor(Date.now() / 1e3) + skew) return conn;
  const res = await fetch(STRAVA_TOKEN, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      client_id: Number(env.STRAVA_CLIENT_ID),
      client_secret: env.STRAVA_CLIENT_SECRET,
      grant_type: "refresh_token",
      refresh_token: conn.refreshToken
    })
  });
  const jsonBody = await res.json();
  if (!res.ok || !jsonBody.access_token || !jsonBody.refresh_token || !jsonBody.expires_at) {
    throw new Error("Strava token refresh failed");
  }
  const next = {
    ...conn,
    accessToken: jsonBody.access_token,
    refreshToken: jsonBody.refresh_token,
    expiresAt: jsonBody.expires_at
  };
  await writeStravaConnection(env, uid, next);
  return next;
}
__name(refreshIfNeeded, "refreshIfNeeded");
async function requireStrava(env, uid) {
  if (!stravaConfigured(env)) {
    return json({ error: "Strava no configurado", code: "strava_not_configured" }, 503);
  }
  const conn = await readStravaConnection(env, uid);
  if (!conn) return json({ error: "Strava no conectado", code: "strava_not_connected" }, 401);
  try {
    return await refreshIfNeeded(env, uid, conn);
  } catch (error) {
    console.error("[strava] refresh", error);
    return json({ error: "Sesi\xF3n Strava caducada; vuelve a conectar", code: "strava_reauth" }, 401);
  }
}
__name(requireStrava, "requireStrava");
async function handleStravaStatus(env, identity) {
  if (!stravaConfigured(env)) {
    return json({ ok: true, configured: false, connected: false });
  }
  const conn = await readStravaConnection(env, identity.uid);
  return json({
    ok: true,
    configured: true,
    connected: Boolean(conn),
    athleteId: conn?.athleteId ?? null
  });
}
__name(handleStravaStatus, "handleStravaStatus");
async function handleStravaDisconnect(env, identity) {
  await deleteStravaConnection(env, identity.uid);
  return json({ ok: true, connected: false });
}
__name(handleStravaDisconnect, "handleStravaDisconnect");
async function handleStravaListActivities(env, identity, request) {
  const connOrErr = await requireStrava(env, identity.uid);
  if (connOrErr instanceof Response) return connOrErr;
  const url = new URL(request.url);
  const page = Math.max(1, Number(url.searchParams.get("page") || 1));
  const perPage = Math.min(50, Math.max(1, Number(url.searchParams.get("per_page") || 20)));
  const res = await fetch(
    `${STRAVA_API}/athlete/activities?page=${page}&per_page=${perPage}`,
    { headers: { Authorization: `Bearer ${connOrErr.accessToken}` } }
  );
  const data = await res.json();
  if (!res.ok) {
    return json({ error: data.message || "Strava list failed" }, 502);
  }
  const activities = data.map((a) => ({
    id: a.id,
    externalId: `strava:${a.id}`,
    name: a.name,
    type: a.sport_type || a.type,
    startedAt: a.start_date,
    durationSeconds: a.elapsed_time,
    distanceMeters: Math.round(a.distance),
    elevationGainMeters: Math.round(a.total_elevation_gain || 0),
    averageHeartRateBpm: a.average_heartrate,
    averageCadenceRpm: a.average_cadence,
    averagePowerWatts: a.average_watts,
    averageSpeedMetersPerSecond: a.average_speed
  }));
  return json({ ok: true, activities });
}
__name(handleStravaListActivities, "handleStravaListActivities");
function bikeTypeFromStrava(type) {
  const t = type.toLowerCase();
  if (t.includes("mountain") || t === "mtb") return "mtb";
  if (t.includes("gravel")) return "gravel";
  if (t.includes("ebike") || t.includes("e-bike")) return "ebike";
  if (t.includes("ride") || t.includes("virtual")) return "road";
  return "road";
}
__name(bikeTypeFromStrava, "bikeTypeFromStrava");
async function handleStravaImportActivity(env, identity, activityId) {
  const connOrErr = await requireStrava(env, identity.uid);
  if (connOrErr instanceof Response) return connOrErr;
  const id = Number(activityId);
  if (!Number.isFinite(id) || id <= 0) return json({ error: "activity id inv\xE1lido" }, 400);
  const metaRes = await fetch(`${STRAVA_API}/activities/${id}`, {
    headers: { Authorization: `Bearer ${connOrErr.accessToken}` }
  });
  const meta = await metaRes.json();
  if (!metaRes.ok) {
    return json({ error: meta.message || "No se pudo leer la actividad Strava" }, 502);
  }
  const keys = ["latlng", "altitude", "time", "heartrate", "cadence", "watts", "velocity_smooth"];
  const streamRes = await fetch(
    `${STRAVA_API}/activities/${id}/streams?keys=${keys.join(",")}&key_by_type=true`,
    { headers: { Authorization: `Bearer ${connOrErr.accessToken}` } }
  );
  const streams = await streamRes.json();
  if (!streamRes.ok) {
    return json(
      { error: streams.message || "No se pudieron leer streams" },
      502
    );
  }
  const set = streams;
  const latlng = set.latlng?.data ?? [];
  const altitude = set.altitude?.data ?? [];
  const time = set.time?.data ?? [];
  const heartrate = set.heartrate?.data ?? [];
  const cadence = set.cadence?.data ?? [];
  const watts = set.watts?.data ?? [];
  const velocity = set.velocity_smooth?.data ?? [];
  const startMs = Date.parse(meta.start_date);
  const n = latlng.length;
  const track = [];
  for (let i = 0; i < n; i += 1) {
    const [lat, lng] = latlng[i];
    const offsetSec = time[i] ?? i;
    track.push({
      position: { lat, lng },
      elevationMeters: Number.isFinite(altitude[i]) ? altitude[i] : void 0,
      recordedAt: new Date(startMs + offsetSec * 1e3).toISOString(),
      heartRateBpm: Number.isFinite(heartrate[i]) ? heartrate[i] : void 0,
      cadenceRpm: Number.isFinite(cadence[i]) ? cadence[i] : void 0,
      powerWatts: Number.isFinite(watts[i]) ? watts[i] : void 0,
      speedMetersPerSecond: Number.isFinite(velocity[i]) ? velocity[i] : void 0
    });
  }
  const maxPts = 3500;
  let capped = track;
  if (track.length > maxPts) {
    const step = Math.ceil(track.length / maxPts);
    capped = track.filter((_, i) => i % step === 0 || i === track.length - 1);
  }
  const finishedAt = new Date(startMs + (meta.elapsed_time || 0) * 1e3).toISOString();
  const activity = {
    userId: identity.uid,
    title: meta.name || "Salida Strava",
    status: "finished",
    bikeType: bikeTypeFromStrava(meta.sport_type || meta.type || "Ride"),
    source: "strava",
    externalId: `strava:${id}`,
    startedAt: meta.start_date,
    finishedAt,
    track: capped,
    stats: {
      distanceMeters: Math.round(meta.distance || 0),
      durationSeconds: meta.elapsed_time || 0,
      elevationGainMeters: Math.round(meta.total_elevation_gain || 0),
      averageHeartRateBpm: meta.average_heartrate,
      averageCadenceRpm: meta.average_cadence,
      averagePowerWatts: meta.average_watts,
      averageSpeedMetersPerSecond: meta.average_speed
    }
  };
  return json({ ok: true, activity });
}
__name(handleStravaImportActivity, "handleStravaImportActivity");

// src/index.ts
function withCors(env, request, response) {
  const headers = new Headers(response.headers);
  const cors = corsHeaders(env, request);
  for (const [k, v] of Object.entries(cors)) headers.set(k, String(v));
  return new Response(response.body, { status: response.status, headers });
}
__name(withCors, "withCors");
async function requireFirebaseUser(env, request) {
  try {
    return await verifyFirebaseIdToken(env, request.headers.get("Authorization"));
  } catch {
    return json(
      {
        error: "Authentication required",
        code: "auth_required",
        hint: "Send Authorization: Bearer <Firebase ID token> (anonymous guests OK)"
      },
      401
    );
  }
}
__name(requireFirebaseUser, "requireFirebaseUser");
var src_default = {
  async fetch(request, env) {
    const url = new URL(request.url);
    const path = url.pathname;
    if (request.method === "OPTIONS") {
      return new Response(null, { status: 204, headers: corsHeaders(env, request) });
    }
    try {
      if (path === "/" && request.method === "GET") {
        return withCors(
          env,
          request,
          json({
            ok: true,
            service: "pedalmap-api",
            hint: "ORS + Valhalla bike routing proxies (auth required)",
            health: "/health"
          })
        );
      }
      if (path === "/health" && request.method === "GET") {
        return withCors(
          env,
          request,
          json({
            ok: true,
            service: "pedalmap-api",
            stack: "cloudflare-workers"
          })
        );
      }
      if (path.startsWith("/v2/directions/") && request.method === "POST") {
        const identity = await requireFirebaseUser(env, request);
        if (identity instanceof Response) return withCors(env, request, identity);
        const limited = await enforceRateLimit(request, {
          limit: 40,
          windowSec: 60,
          prefix: "ors",
          key: identity.uid
        });
        if (limited) return withCors(env, request, limited);
        return withCors(env, request, await handleOrsProxy(request, env, path));
      }
      if (path === "/valhalla/bike-route" && request.method === "POST") {
        const identity = await requireFirebaseUser(env, request);
        if (identity instanceof Response) return withCors(env, request, identity);
        const limited = await enforceRateLimit(request, {
          limit: 30,
          windowSec: 60,
          prefix: "valhalla-bike",
          key: identity.uid
        });
        if (limited) return withCors(env, request, limited);
        return withCors(env, request, await handleBikeRoute(request, env));
      }
      if (path === "/valhalla/route" && request.method === "POST") {
        const identity = await requireFirebaseUser(env, request);
        if (identity instanceof Response) return withCors(env, request, identity);
        const limited = await enforceRateLimit(request, {
          limit: 40,
          windowSec: 60,
          prefix: "valhalla",
          key: identity.uid
        });
        if (limited) return withCors(env, request, limited);
        return withCors(env, request, await handleValhallaProxy(request, env, "route"));
      }
      if (path === "/valhalla/trace_attributes" && request.method === "POST") {
        const identity = await requireFirebaseUser(env, request);
        if (identity instanceof Response) return withCors(env, request, identity);
        const limited = await enforceRateLimit(request, {
          limit: 60,
          windowSec: 60,
          prefix: "valhalla-attr",
          key: identity.uid
        });
        if (limited) return withCors(env, request, limited);
        return withCors(
          env,
          request,
          await handleValhallaProxy(request, env, "trace_attributes")
        );
      }
      if (path === "/valhalla/height" && request.method === "POST") {
        const identity = await requireFirebaseUser(env, request);
        if (identity instanceof Response) return withCors(env, request, identity);
        const limited = await enforceRateLimit(request, {
          limit: 60,
          windowSec: 60,
          prefix: "valhalla-height",
          key: identity.uid
        });
        if (limited) return withCors(env, request, limited);
        return withCors(env, request, await handleValhallaProxy(request, env, "height"));
      }
      if (path === "/me/sync-plan" && request.method === "POST") {
        const identity = await requireFirebaseUser(env, request);
        if (identity instanceof Response) return withCors(env, request, identity);
        const limited = await enforceRateLimit(request, {
          limit: 20,
          windowSec: 60,
          prefix: "sync-plan",
          key: identity.uid
        });
        if (limited) return withCors(env, request, limited);
        return withCors(env, request, await handleSyncPlan(env, identity));
      }
      if (path === "/me/entitlements" && request.method === "GET") {
        const identity = await requireFirebaseUser(env, request);
        if (identity instanceof Response) return withCors(env, request, identity);
        const limited = await enforceRateLimit(request, {
          limit: 60,
          windowSec: 60,
          prefix: "entitlements",
          key: identity.uid
        });
        if (limited) return withCors(env, request, limited);
        return withCors(env, request, await handleEntitlements(env, identity));
      }
      if (path === "/stripe/checkout" && request.method === "POST") {
        const limited = await enforceRateLimit(request, {
          limit: 20,
          windowSec: 60,
          prefix: "stripe"
        });
        if (limited) return withCors(env, request, limited);
        return withCors(env, request, await handleCheckout(request, env));
      }
      if (path === "/stripe/portal" && request.method === "POST") {
        const limited = await enforceRateLimit(request, {
          limit: 20,
          windowSec: 60,
          prefix: "stripe"
        });
        if (limited) return withCors(env, request, limited);
        return withCors(env, request, await handlePortal(request, env));
      }
      if (path === "/stripe/webhook" && request.method === "POST") {
        return handleWebhook(request, env);
      }
      if (path === "/strava/oauth/start" && request.method === "POST") {
        const identity = await requireFirebaseUser(env, request);
        if (identity instanceof Response) return withCors(env, request, identity);
        const limited = await enforceRateLimit(request, {
          limit: 20,
          windowSec: 60,
          prefix: "strava-oauth",
          key: identity.uid
        });
        if (limited) return withCors(env, request, limited);
        return withCors(env, request, await handleStravaOAuthStart(request, env, identity));
      }
      if (path === "/strava/oauth/callback" && request.method === "GET") {
        return handleStravaOAuthCallback(request, env);
      }
      if (path === "/strava/status" && request.method === "GET") {
        const identity = await requireFirebaseUser(env, request);
        if (identity instanceof Response) return withCors(env, request, identity);
        return withCors(env, request, await handleStravaStatus(env, identity));
      }
      if (path === "/strava/disconnect" && request.method === "POST") {
        const identity = await requireFirebaseUser(env, request);
        if (identity instanceof Response) return withCors(env, request, identity);
        return withCors(env, request, await handleStravaDisconnect(env, identity));
      }
      if (path === "/strava/activities" && request.method === "GET") {
        const identity = await requireFirebaseUser(env, request);
        if (identity instanceof Response) return withCors(env, request, identity);
        const limited = await enforceRateLimit(request, {
          limit: 30,
          windowSec: 60,
          prefix: "strava-list",
          key: identity.uid
        });
        if (limited) return withCors(env, request, limited);
        return withCors(env, request, await handleStravaListActivities(env, identity, request));
      }
      {
        const importMatch = path.match(/^\/strava\/activities\/(\d+)\/import$/);
        if (importMatch && request.method === "POST") {
          const identity = await requireFirebaseUser(env, request);
          if (identity instanceof Response) return withCors(env, request, identity);
          const limited = await enforceRateLimit(request, {
            limit: 20,
            windowSec: 60,
            prefix: "strava-import",
            key: identity.uid
          });
          if (limited) return withCors(env, request, limited);
          return withCors(
            env,
            request,
            await handleStravaImportActivity(env, identity, importMatch[1])
          );
        }
      }
      return withCors(env, request, json({ error: "Not found", path }, 404));
    } catch (error) {
      const message2 = error instanceof Error ? error.message : "Unhandled error";
      const status = message2.includes("Bearer") || message2.includes("token") ? 401 : 500;
      console.error("[worker]", message2);
      return withCors(env, request, json({ error: message2 }, status));
    }
  }
};

// node_modules/wrangler/templates/middleware/middleware-ensure-req-body-drained.ts
var drainBody = /* @__PURE__ */ __name(async (request, env, _ctx, middlewareCtx) => {
  try {
    return await middlewareCtx.next(request, env);
  } finally {
    try {
      if (request.body !== null && !request.bodyUsed) {
        const reader = request.body.getReader();
        while (!(await reader.read()).done) {
        }
      }
    } catch (e) {
      console.error("Failed to drain the unused request body.", e);
    }
  }
}, "drainBody");
var middleware_ensure_req_body_drained_default = drainBody;

// node_modules/wrangler/templates/middleware/middleware-miniflare3-json-error.ts
function reduceError(e) {
  return {
    name: e?.name,
    message: e?.message ?? String(e),
    stack: e?.stack,
    cause: e?.cause === void 0 ? void 0 : reduceError(e.cause)
  };
}
__name(reduceError, "reduceError");
var jsonError = /* @__PURE__ */ __name(async (request, env, _ctx, middlewareCtx) => {
  try {
    return await middlewareCtx.next(request, env);
  } catch (e) {
    const error = reduceError(e);
    const body = JSON.stringify(error);
    const headers = {
      "Content-Type": "application/json",
      "MF-Experimental-Error-Stack": "true"
    };
    const encoded = encodeURIComponent(body);
    if (encoded.length <= 8192) {
      headers["MF-Experimental-Error-Stack-Payload"] = encoded;
    }
    return new Response(body, { status: 500, headers });
  }
}, "jsonError");
var middleware_miniflare3_json_error_default = jsonError;

// .wrangler/tmp/bundle-sgBAot/middleware-insertion-facade.js
var __INTERNAL_WRANGLER_MIDDLEWARE__ = [
  middleware_ensure_req_body_drained_default,
  middleware_miniflare3_json_error_default
];
var middleware_insertion_facade_default = src_default;

// node_modules/wrangler/templates/middleware/common.ts
var __facade_middleware__ = [];
function __facade_register__(...args) {
  __facade_middleware__.push(...args.flat());
}
__name(__facade_register__, "__facade_register__");
function __facade_invokeChain__(request, env, ctx, dispatch, middlewareChain) {
  const [head, ...tail] = middlewareChain;
  const middlewareCtx = {
    dispatch,
    next(newRequest, newEnv) {
      return __facade_invokeChain__(newRequest, newEnv, ctx, dispatch, tail);
    }
  };
  return head(request, env, ctx, middlewareCtx);
}
__name(__facade_invokeChain__, "__facade_invokeChain__");
function __facade_invoke__(request, env, ctx, dispatch, finalMiddleware) {
  return __facade_invokeChain__(request, env, ctx, dispatch, [
    ...__facade_middleware__,
    finalMiddleware
  ]);
}
__name(__facade_invoke__, "__facade_invoke__");

// .wrangler/tmp/bundle-sgBAot/middleware-loader.entry.ts
var __Facade_ScheduledController__ = class ___Facade_ScheduledController__ {
  constructor(scheduledTime, cron, noRetry) {
    this.scheduledTime = scheduledTime;
    this.cron = cron;
    this.#noRetry = noRetry;
  }
  scheduledTime;
  cron;
  static {
    __name(this, "__Facade_ScheduledController__");
  }
  #noRetry;
  noRetry() {
    if (!(this instanceof ___Facade_ScheduledController__)) {
      throw new TypeError("Illegal invocation");
    }
    this.#noRetry();
  }
};
function wrapExportedHandler(worker) {
  if (__INTERNAL_WRANGLER_MIDDLEWARE__ === void 0 || __INTERNAL_WRANGLER_MIDDLEWARE__.length === 0) {
    return worker;
  }
  for (const middleware of __INTERNAL_WRANGLER_MIDDLEWARE__) {
    __facade_register__(middleware);
  }
  const fetchDispatcher = /* @__PURE__ */ __name(function(request, env, ctx) {
    if (worker.fetch === void 0) {
      throw new Error("Handler does not export a fetch() function.");
    }
    return worker.fetch(request, env, ctx);
  }, "fetchDispatcher");
  return {
    ...worker,
    fetch(request, env, ctx) {
      const dispatcher = /* @__PURE__ */ __name(function(type, init) {
        if (type === "scheduled" && worker.scheduled !== void 0) {
          const controller = new __Facade_ScheduledController__(
            Date.now(),
            init.cron ?? "",
            () => {
            }
          );
          return worker.scheduled(controller, env, ctx);
        }
      }, "dispatcher");
      return __facade_invoke__(request, env, ctx, dispatcher, fetchDispatcher);
    }
  };
}
__name(wrapExportedHandler, "wrapExportedHandler");
function wrapWorkerEntrypoint(klass) {
  if (__INTERNAL_WRANGLER_MIDDLEWARE__ === void 0 || __INTERNAL_WRANGLER_MIDDLEWARE__.length === 0) {
    return klass;
  }
  for (const middleware of __INTERNAL_WRANGLER_MIDDLEWARE__) {
    __facade_register__(middleware);
  }
  return class extends klass {
    #fetchDispatcher = /* @__PURE__ */ __name((request, env, ctx) => {
      this.env = env;
      this.ctx = ctx;
      if (super.fetch === void 0) {
        throw new Error("Entrypoint class does not define a fetch() function.");
      }
      return super.fetch(request);
    }, "#fetchDispatcher");
    #dispatcher = /* @__PURE__ */ __name((type, init) => {
      if (type === "scheduled" && super.scheduled !== void 0) {
        const controller = new __Facade_ScheduledController__(
          Date.now(),
          init.cron ?? "",
          () => {
          }
        );
        return super.scheduled(controller);
      }
    }, "#dispatcher");
    fetch(request) {
      return __facade_invoke__(
        request,
        this.env,
        this.ctx,
        this.#dispatcher,
        this.#fetchDispatcher
      );
    }
  };
}
__name(wrapWorkerEntrypoint, "wrapWorkerEntrypoint");
var WRAPPED_ENTRY;
if (typeof middleware_insertion_facade_default === "object") {
  WRAPPED_ENTRY = wrapExportedHandler(middleware_insertion_facade_default);
} else if (typeof middleware_insertion_facade_default === "function") {
  WRAPPED_ENTRY = wrapWorkerEntrypoint(middleware_insertion_facade_default);
}
var middleware_loader_entry_default = WRAPPED_ENTRY;
export {
  __INTERNAL_WRANGLER_MIDDLEWARE__,
  middleware_loader_entry_default as default
};
//# sourceMappingURL=index.js.map
